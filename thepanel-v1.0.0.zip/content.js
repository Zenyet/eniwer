var We=Object.defineProperty;var Je=(u,f,y)=>f in u?We(u,f,{enumerable:!0,configurable:!0,writable:!0,value:y}):u[f]=y;var d=(u,f,y)=>Je(u,typeof f!="symbol"?f+"":f,y);(function(){"use strict";const u={translate:'<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m5 8 6 6"/><path d="m4 14 6-6 2-3"/><path d="M2 5h12"/><path d="M7 2h1"/><path d="m22 22-5-10-5 10"/><path d="M14 18h6"/></svg>',summarize:'<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="4" y1="6" x2="20" y2="6"/><line x1="4" y1="10" x2="20" y2="10"/><line x1="4" y1="14" x2="16" y2="14"/><line x1="4" y1="18" x2="14" y2="18"/></svg>',explain:'<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/><path d="M12 17h.01"/></svg>',rewrite:'<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.375 2.625a1 1 0 0 1 3 3l-9.013 9.014a2 2 0 0 1-.853.505l-2.873.84a.5.5 0 0 1-.62-.62l.84-2.873a2 2 0 0 1 .506-.852z"/></svg>',search:'<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg>',copy:'<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect width="14" height="14" x="8" y="8" rx="2" ry="2"/><path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"/></svg>',sendToAI:'<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 2 11 13"/><path d="M22 2 15 22 11 13 2 9l20-7z"/></svg>',codeExplain:'<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="16 18 22 12 16 6"/><polyline points="8 6 2 12 8 18"/></svg>',summarizePage:'<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"/><path d="M14 2v4a2 2 0 0 0 2 2h4"/><path d="M10 9H8"/><path d="M16 13H8"/><path d="M16 17H8"/></svg>',history:'<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"/><path d="M3 3v5h5"/><path d="M12 7v5l4 2"/></svg>',screenshot:'<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14.5 4h-5L7 7H4a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-3l-2.5-3z"/><circle cx="12" cy="13" r="3"/></svg>',settings:'<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"/><circle cx="12" cy="12" r="3"/></svg>',messageCircle:'<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M7.9 20A9 9 0 1 0 4 16.1L2 22Z"/></svg>',columns:'<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3h7a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-7m0-18H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h7m0-18v18"/></svg>',logo:'<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 128 128" fill="none" stroke="currentColor" stroke-width="12" stroke-linecap="round" stroke-linejoin="round"><circle cx="64" cy="64" r="56"/><circle cx="64" cy="64" fill="currentColor" r="33"/></svg>'},f={saveToFile:!0,copyToClipboard:!1,enableAI:!0,defaultAIAction:"none",imageQuality:.92,enableImageGen:!1,imageGenProvider:"openai",imageSize:"1024x1024"},y={maxSaveCount:100,panelDisplayCount:10},C={shortcut:"Double+Shift",theme:"system",preferredLanguage:"zh-CN",summaryLanguage:"auto",apiProvider:"groq",useStreaming:!0,screenshot:f,popoverPosition:"above",history:y},ee=[{id:"translate",icon:u.translate,label:"翻译",action:"translate",enabled:!0,order:0},{id:"summarize",icon:u.summarize,label:"总结",action:"summarize",enabled:!0,order:1},{id:"explain",icon:u.explain,label:"解释",action:"explain",enabled:!0,order:2},{id:"rewrite",icon:u.rewrite,label:"改写",action:"rewrite",enabled:!0,order:3},{id:"search",icon:u.search,label:"搜索",action:"search",enabled:!0,order:4},{id:"copy",icon:u.copy,label:"复制",action:"copy",enabled:!0,order:5},{id:"sendToAI",icon:u.sendToAI,label:"发送到 AI",action:"sendToAI",enabled:!0,order:6},{id:"codeExplain",icon:u.codeExplain,label:"代码解释",action:"codeExplain",enabled:!0,order:7}],H=[{id:"contextChat",icon:u.messageCircle,label:"上下文追问",action:"contextChat",enabled:!0,order:0},{id:"summarizePage",icon:u.summarizePage,label:"总结页面",action:"summarizePage",enabled:!0,order:1},{id:"browseTrail",icon:u.history,label:"浏览轨迹",action:"browseTrail",enabled:!0,order:2},{id:"screenshot",icon:u.screenshot,label:"截图",action:"screenshot",enabled:!0,order:3},{id:"settings",icon:u.settings,label:"设置",action:"settings",enabled:!0,order:4}],B="thecircle_data";async function K(){const c=await chrome.storage.local.get(B);return c[B]?c[B]:{config:C,selectionMenuItems:ee,globalMenuItems:H}}async function te(c){const t={...await K(),...c};await chrome.storage.local.set({[B]:t})}async function se(c){const e=await K();e.config={...e.config,...c},await te(e)}async function j(c){await te({globalMenuItems:c})}const F="thecircle_saved_tasks";async function _(){return(await chrome.storage.local.get(F))[F]||[]}async function N(c){await chrome.storage.local.set({[F]:c})}async function ae(c){const e=await _(),t={...c,id:`task-${Date.now()}-${Math.random().toString(36).substr(2,9)}`,savedAt:Date.now()};return e.unshift(t),await N(e),t}async function ie(c=50,e=0){return(await _()).slice(e,e+c)}async function ne(c){const t=(await _()).filter(s=>s.id!==c);await N(t)}async function Te(){await N([])}async function Y(c){const e=await _();if(e.length<=c)return;const t=e.slice(0,c);await N(t)}const Se=Object.freeze(Object.defineProperty({__proto__:null,clearAllTasks:Te,deleteTask:ne,enforceMaxCount:Y,getAllTasks:ie,saveTask:ae},Symbol.toStringTag,{value:"Module"})),x="thecircle_browse_trail",oe=1e3;async function re(){try{return(await chrome.storage.local.get(x))[x]||[]}catch{return[]}}async function Ce(c){const e=await re();for(const s of e)s.entries=s.entries.filter(i=>i.id!==c);const t=e.filter(s=>s.entries.length>0);return await chrome.storage.local.set({[x]:t}),t}async function le(){await chrome.storage.local.set({[x]:[]})}function Le(c){const e=[];for(const n of c)e.push(...n.entries);const t=e.map(n=>({title:n.title,url:n.url,visitedAt:new Date(n.visitedAt).toISOString(),summary:n.summary})),s=new Blob([JSON.stringify(t,null,2)],{type:"application/json"}),i=URL.createObjectURL(s),a=document.createElement("a");a.href=i,a.download=`browse-trail-${new Date().toISOString().split("T")[0]}.json`,a.click(),URL.revokeObjectURL(i)}function Re(c){let e=0;for(const t of c)e+=t.entries.length;return e}function ce(c,e){let t=Re(c);if(t<=e)return c;for(let s=c.length-1;s>=0&&t>e;s--){const i=c[s],a=t-e;i.entries.length<=a?(t-=i.entries.length,c.splice(s,1)):(i.entries.splice(0,a),t-=a)}return c.filter(s=>s.entries.length>0)}class Ae{constructor(){d(this,"currentSessionId");d(this,"recordingEnabled",!0);this.currentSessionId=this.generateId(),this.startRecording()}async startRecording(){await this.recordPage()}async recordPage(){if(!this.recordingEnabled)return;const e={id:this.generateId(),url:window.location.href,title:document.title,visitedAt:Date.now(),sessionId:this.currentSessionId};if(!this.shouldSkip(e.url))try{const s=(await chrome.storage.local.get(x))[x]||[];let i=s.find(l=>l.id===this.currentSessionId);i||(i={id:this.currentSessionId,startedAt:Date.now(),entries:[]},s.unshift(i));const a=3e4,n=Date.now();for(const l of s){if(l.entries.length>0&&n-l.entries[l.entries.length-1].visitedAt>a)break;for(let h=l.entries.length-1;h>=0;h--){const g=l.entries[h];if(n-g.visitedAt>a)break;if(g.url===e.url)return}}i.entries.push(e);const o=Date.now()-30*24*60*60*1e3;let r=s.filter(l=>l.startedAt>o);r=ce(r,oe),await chrome.storage.local.set({[x]:r})}catch(t){if(this.isQuotaError(t)){await this.emergencyCleanup();return}console.error("Failed to record page:",t)}}isQuotaError(e){return!!(e instanceof DOMException&&e.name==="QuotaExceededError"||e instanceof Error&&e.message.includes("QUOTA_BYTES"))}async emergencyCleanup(){try{const t=(await chrome.storage.local.get(x))[x]||[],s=ce(t,Math.floor(oe/2));await chrome.storage.local.set({[x]:s})}catch{await le()}}shouldSkip(e){return[/^chrome:/,/^chrome-extension:/,/^about:/,/^data:/,/^blob:/,/^javascript:/].some(s=>s.test(e))}generateId(){return`${Date.now()}-${Math.random().toString(36).slice(2,9)}`}}const X="thecircle_chat_sessions",Ie=100;async function Me(c){return(await de()).find(t=>t.url===c)||null}async function de(){try{return(await chrome.storage.local.get(X))[X]||[]}catch{return[]}}async function he(c){const e=await de(),t=e.findIndex(a=>a.id===c.id);c.updatedAt=Date.now(),t>=0?e[t]=c:e.push(c);const i=e.sort((a,n)=>n.updatedAt-a.updatedAt).slice(0,Ie);await chrome.storage.local.set({[X]:i})}function ge(c,e){return{id:`${Date.now()}-${Math.random().toString(36).slice(2,9)}`,url:c,title:e,messages:[],pageContext:document.body.innerText.slice(0,1e4),updatedAt:Date.now()}}function ue(c,e,t){return{id:`${Date.now()}-${Math.random().toString(36).slice(2,9)}`,role:c,content:e,timestamp:Date.now(),references:t}}function De(c){return`You are a helpful assistant answering questions about a webpage.

Page Title: ${c.title}
Page URL: ${c.url}

Page Content (truncated):
${c.pageContext}

Instructions:
- Answer questions based on the page content above
- If the answer is not in the content, say so
- Be concise but thorough
- Use the same language as the user's question
- If the user references specific text with @"...", pay special attention to that text`}function Ee(c){return c.map(e=>{let t=e.content;return e.references&&e.references.length>0&&(t=`[Referenced text: ${e.references.map(s=>`"${s.text}"`).join(", ")}]
${t}`),`${e.role==="user"?"User":"Assistant"}: ${t}`}).join(`

`)}function ze(c){const e=[],t=/@"([^"]+)"/g;let s;for(;(s=t.exec(c))!==null;)e.push({text:s[1]});const i=c.replace(t,"").trim()||c;return{text:c,cleanContent:i,references:e}}const q=new Map;function pe(){return`${Date.now()}-${Math.random().toString(36).slice(2,9)}`}function V(){for(const[c,e]of q){try{e.port.disconnect()}catch{}q.delete(c)}}async function O(c,e,t,s){return t.useStreaming&&!!s?Pe("AI_REQUEST",{action:"custom",text:c,systemPrompt:e,config:t},s):await chrome.runtime.sendMessage({type:"AI_REQUEST",payload:{action:"custom",text:c,systemPrompt:e,config:t}})}async function Q(c,e,t,s){return t.useStreaming&&!!s?He(c,e,t,s):await chrome.runtime.sendMessage({type:"AI_VISION_REQUEST",payload:{imageDataUrl:c,prompt:e,config:t}})}async function $e(c,e,t){return await chrome.runtime.sendMessage({type:"AI_IMAGE_GEN_REQUEST",payload:{prompt:c,config:e,screenshotConfig:t}})}async function Pe(c,e,t){return new Promise(s=>{const i=pe(),a=chrome.runtime.connect({name:"ai-stream"});q.set(i,{port:a,requestId:i});const n=()=>{q.delete(i);try{a.onMessage.removeListener(o)}catch{}},o=r=>{var l;((l=r.payload)==null?void 0:l.requestId)===i&&(r.type==="AI_STREAM_CHUNK"?t(r.payload.chunk||"",r.payload.fullText||""):r.type==="AI_STREAM_END"?(n(),a.disconnect(),s({success:r.payload.success||!1,result:r.payload.result,error:r.payload.error,requestId:i})):r.type==="AI_STREAM_ERROR"&&(n(),a.disconnect(),s({success:!1,error:r.payload.error||"Unknown error",requestId:i})))};a.onDisconnect.addListener(()=>{n(),s({success:!1,error:"请求已取消",requestId:i})}),a.onMessage.addListener(o),a.postMessage({type:c,payload:{...e,requestId:i}})})}async function He(c,e,t,s){return new Promise(i=>{const a=pe(),n=chrome.runtime.connect({name:"ai-stream"});q.set(a,{port:n,requestId:a});const o=()=>{q.delete(a);try{n.onMessage.removeListener(r)}catch{}},r=l=>{var h;((h=l.payload)==null?void 0:h.requestId)===a&&(l.type==="AI_STREAM_CHUNK"?s(l.payload.chunk||"",l.payload.fullText||""):l.type==="AI_STREAM_END"?(o(),n.disconnect(),i({success:l.payload.success||!1,result:l.payload.result,error:l.payload.error,requestId:a})):l.type==="AI_STREAM_ERROR"&&(o(),n.disconnect(),i({success:!1,error:l.payload.error||"Unknown error",requestId:a})))};n.onDisconnect.addListener(()=>{o(),i({success:!1,error:"请求已取消",requestId:a})}),n.onMessage.addListener(r),n.postMessage({type:"AI_VISION_REQUEST",payload:{imageDataUrl:c,prompt:e,config:t,requestId:a}})})}function me(c){return`You are a professional translator. Translate the following text to ${c}. Only output the translation, nothing else.`}function ve(c){const e=c.trim();return e?{auto:"the same language as the input","zh-CN":"Simplified Chinese","zh-TW":"Traditional Chinese",en:"English",ja:"Japanese",ko:"Korean",es:"Spanish",fr:"French",de:"German"}[e]||e:c}function qe(c="auto"){return c==="auto"?"You are a summarization expert. Summarize the following text in a concise manner, keeping the key points. Use bullet points if appropriate. Output in the same language as the input.":`You are a summarization expert. Summarize the following text in a concise manner, keeping the key points. Use bullet points if appropriate. Output in ${ve(c)}.`}function Ve(){return"You are a helpful teacher. Explain the following text in simple terms that anyone can understand. Output in the same language as the input."}function G(){return"You are a professional editor. Rewrite the following text to make it clearer, more engaging, and well-structured. Keep the same meaning. Output in the same language as the input."}function Ue(){return"You are a senior software engineer. Explain the following code in detail, including what it does, how it works, and any important concepts. Output in the same language as the input text (if any) or in English."}function Be(c="auto"){return c==="auto"?"You are a summarization expert. Summarize the following webpage content in a comprehensive but concise manner. Include the main topic, key points, and any important details. Use bullet points for clarity. Output in the same language as the content.":`You are a summarization expert. Summarize the following webpage content in a comprehensive but concise manner. Include the main topic, key points, and any important details. Use bullet points for clarity. Output in ${ve(c)}.`}function Ke(){return`请详细描述这张图片的内容，包括：
1. 主要元素和对象
2. 场景和环境
3. 颜色和视觉特征
4. 任何文字或标识
5. 整体氛围和主题

请用中文回答。`}function je(c){return`请根据这张图片回答以下问题：

${c}

请用中文回答，尽量详细和准确。`}class _e{constructor(e){d(this,"container",null);d(this,"shadowRoot",null);d(this,"config");d(this,"menuItems",[]);d(this,"filteredItems",[]);d(this,"selectedIndex",0);d(this,"callbacks",null);d(this,"recentCommands",[]);d(this,"searchQuery","");d(this,"theme","dark");d(this,"viewStack",[]);d(this,"currentView","commands");d(this,"activeCommand",null);d(this,"activeCommandInput","");d(this,"aiResultData",null);d(this,"aiResultCallbacks",null);d(this,"screenshotData",null);d(this,"screenshotCallbacks",null);d(this,"settingsMenuItems",[]);d(this,"editingItemId",null);d(this,"tempConfig",null);d(this,"settingsChanged",!1);d(this,"browseTrailSessions",[]);d(this,"browseTrailSearch","");d(this,"browseTrailDisplayCount",50);d(this,"chatSession",null);d(this,"isChatStreaming",!1);d(this,"isQuickAsk",!1);d(this,"isDragging",!1);d(this,"dragStartX",0);d(this,"dragStartY",0);d(this,"panelStartX",0);d(this,"panelStartY",0);d(this,"savedPanelPosition",null);d(this,"minimizedTasks",[]);d(this,"minimizedTaskIdCounter",0);d(this,"currentStreamKey",null);d(this,"recentSavedTasks",[]);d(this,"handleAIResultKeydown",e=>{e.key==="Escape"&&this.currentView==="ai-result"&&(e.preventDefault(),document.removeEventListener("keydown",this.handleAIResultKeydown),this.aiResultData&&this.minimize(),this.activeCommand=null,this.currentView="commands",this.viewStack=[],this.aiResultData=null,this.aiResultCallbacks=null,this.renderCurrentView(!0,!0))});d(this,"handleDragStart",e=>{var a;const t=e.target;if(t.closest("button")||t.closest("select")||t.closest("input"))return;const s=(a=this.shadowRoot)==null?void 0:a.querySelector(".glass-panel");if(!s)return;this.isDragging=!0,this.dragStartX=e.clientX,this.dragStartY=e.clientY;const i=s.getBoundingClientRect();this.panelStartX=i.left,this.panelStartY=i.top,s.style.position="fixed",s.style.left=`${i.left}px`,s.style.top=`${i.top}px`,s.style.transform="none",s.classList.add("glass-panel-dragging"),document.addEventListener("mousemove",this.handleDragMove),document.addEventListener("mouseup",this.handleDragEnd),e.preventDefault()});d(this,"handleDragMove",e=>{var h;if(!this.isDragging)return;const t=(h=this.shadowRoot)==null?void 0:h.querySelector(".glass-panel");if(!t)return;const s=e.clientX-this.dragStartX,i=e.clientY-this.dragStartY;let a=this.panelStartX+s,n=this.panelStartY+i;const o=t.getBoundingClientRect(),r=window.innerWidth-o.width,l=window.innerHeight-o.height;a=Math.max(0,Math.min(a,r)),n=Math.max(0,Math.min(n,l)),t.style.left=`${a}px`,t.style.top=`${n}px`});d(this,"handleDragEnd",()=>{var t;this.isDragging=!1;const e=(t=this.shadowRoot)==null?void 0:t.querySelector(".glass-panel");e&&e.classList.remove("glass-panel-dragging"),document.removeEventListener("mousemove",this.handleDragMove),document.removeEventListener("mouseup",this.handleDragEnd)});d(this,"handleScreenshotKeydown",e=>{var t,s;e.key==="Escape"&&this.currentView==="screenshot"&&(e.preventDefault(),document.removeEventListener("keydown",this.handleScreenshotKeydown),this.screenshotData=null,(s=(t=this.screenshotCallbacks)==null?void 0:t.onClose)==null||s.call(t),this.screenshotCallbacks=null,this.activeCommand=null,this.currentView="commands",this.renderCurrentView(!0,!0))});this.config=e,this.loadRecentCommands(),this.updateTheme(),this.loadRecentSavedTasks()}setConfig(e){this.config=e,this.updateTheme(),this.loadRecentSavedTasks()}updateTheme(e){const t=e??this.config.theme;t==="light"?this.theme="light":t==="dark"?this.theme="dark":this.theme=window.matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light"}show(e,t){this.menuItems=e.filter(s=>s.enabled!==!1),this.filteredItems=this.sortByRecent(this.menuItems),this.callbacks=t,this.selectedIndex=0,this.searchQuery="",this.currentView="commands",this.viewStack=[],this.activeCommand=null,this.activeCommandInput="",this.aiResultData=null,this.aiResultCallbacks=null,this.updateTheme(),this.loadRecentSavedTasks(),this.render()}hide(){var e,t,s;if(this.container){document.removeEventListener("mousemove",this.handleDragMove),document.removeEventListener("mouseup",this.handleDragEnd);const i=((t=(e=this.activeCommand)==null?void 0:e.id)==null?void 0:t.startsWith("saved_"))??!1;this.aiResultData&&!i&&this.minimize();const a=(s=this.shadowRoot)==null?void 0:s.querySelector(".glass-panel");a&&(this.savedPanelPosition={top:a.style.top,left:a.style.left,right:a.style.right,transform:a.style.transform},a.style.transform==="none"?a.classList.add("glass-panel-exit-dragged"):a.classList.add("glass-panel-exit")),setTimeout(()=>{var n,o;(n=this.container)==null||n.remove(),this.container=null,this.shadowRoot=null,(o=this.callbacks)==null||o.onClose(),this.viewStack=[],this.currentView="commands",this.aiResultData=null,this.aiResultCallbacks=null},250)}}isVisible(){return this.container!==null}pushView(e){this.viewStack.push({type:this.currentView,title:this.getViewTitle(this.currentView),data:this.getViewData()}),this.currentView=e.type,this.renderCurrentView(!0,!0)}popView(){const e=this.viewStack.pop();e&&(this.currentView=e.type,this.restoreViewData(e),this.renderCurrentView(!0,!0))}getViewTitle(e){var s;return{commands:"命令","ai-result":((s=this.aiResultData)==null?void 0:s.title)||"AI 结果",settings:"设置","settings-menu":"菜单管理",screenshot:"截图",browseTrail:"浏览轨迹",contextChat:"上下文追问"}[e]}getViewData(){return this.currentView==="ai-result"?this.aiResultData:null}restoreViewData(e){e.type==="ai-result"&&e.data&&(this.aiResultData=e.data)}showAIResult(e,t,s){const i=(s==null?void 0:s.actionType)||"";if(i){const a=this.minimizedTasks.find(n=>n.actionType===i);if(a)return this.aiResultCallbacks=t||null,this.restoreMinimizedTask(a.id),!0}return this.currentStreamKey=`stream-${Date.now()}-${Math.random().toString(36).substr(2,9)}`,this.aiResultData={title:e,content:"",originalText:(s==null?void 0:s.originalText)||"",isLoading:!0,resultType:(s==null?void 0:s.resultType)||"general",translateTargetLanguage:(s==null?void 0:s.translateTargetLanguage)||this.config.preferredLanguage||"zh-CN",iconHtml:s==null?void 0:s.iconHtml,streamKey:this.currentStreamKey,actionType:i,sourceUrl:(s==null?void 0:s.sourceUrl)||window.location.href,sourceTitle:(s==null?void 0:s.sourceTitle)||document.title,createdAt:Date.now()},this.aiResultCallbacks=t||null,this.currentView="commands",this.viewStack=[],this.container?this.renderCurrentView():(this.updateTheme(),this.render()),!1}setActiveCommand(e){this.activeCommand=e,this.activeCommandInput="",this.searchQuery=""}showScreenshot(e,t){this.activeCommand={id:"screenshot",action:"screenshot",label:"截图",icon:"",enabled:!0,order:0},this.screenshotData={dataUrl:e,isLoading:!1},this.screenshotCallbacks=t||null,this.currentView="screenshot",this.viewStack=[],this.container?this.renderCurrentView():(this.updateTheme(),this.render())}updateScreenshotResult(e,t=!1){this.screenshotData&&(this.screenshotData.result=e,this.screenshotData.isLoading=t,this.renderScreenshotContent())}updateScreenshotGeneratedImage(e){this.screenshotData&&(this.screenshotData.generatedImageUrl=e,this.screenshotData.isLoading=!1,this.renderScreenshotContent())}renderScreenshotContent(){if(!this.shadowRoot||!this.screenshotData)return;const e=this.shadowRoot.querySelector(".glass-screenshot-content");e&&(e.innerHTML=this.getScreenshotContentHTML())}streamUpdate(e,t){if(this.aiResultData&&this.aiResultData.streamKey===this.currentStreamKey&&(this.aiResultData.content=t,this.aiResultData.isLoading=!0,this.currentView==="commands"&&this.activeCommand?this.updateUnifiedContent():this.updateAIResultContent()),this.currentStreamKey){const s=this.minimizedTasks.find(i=>i.streamKey===this.currentStreamKey);s&&(s.content=t,s.isLoading=!0)}}updateAIResult(e){if(this.aiResultData&&this.aiResultData.streamKey===this.currentStreamKey&&(this.aiResultData.content=e,this.aiResultData.isLoading=!1,this.currentView==="commands"&&this.activeCommand?this.updateUnifiedContent():this.updateAIResultContent()),this.currentStreamKey){const t=this.minimizedTasks.find(s=>s.streamKey===this.currentStreamKey);if(t){t.content=e;const s=t.isLoading;t.isLoading=!1,s&&this.renderMinimizedTasksIfVisible()}this.currentStreamKey=null}}setAIResultLoading(e){if(this.aiResultData&&this.aiResultData.streamKey===this.currentStreamKey&&(this.aiResultData.isLoading=e,this.currentView==="commands"&&this.activeCommand?this.updateUnifiedContent():this.updateAIResultContent()),this.currentStreamKey){const t=this.minimizedTasks.find(s=>s.streamKey===this.currentStreamKey);if(t){const s=t.isLoading;t.isLoading=e,s!==e&&this.renderMinimizedTasksIfVisible()}e||(this.currentStreamKey=null)}}renderMinimizedTasksIfVisible(){this.currentView==="commands"&&this.shadowRoot&&this.renderMinimizedTasks()}showSettings(){this.tempConfig=JSON.parse(JSON.stringify(this.config)),this.settingsChanged=!1,this.currentView="settings",this.viewStack=[],this.container?this.renderCurrentView():(this.updateTheme(),this.render())}async loadRecentCommands(){try{const e=await chrome.storage.local.get("thecircle_recent_commands");this.recentCommands=e.thecircle_recent_commands||[]}catch{this.recentCommands=[]}}async saveRecentCommand(e){this.recentCommands=[e,...this.recentCommands.filter(t=>t!==e)].slice(0,5),await chrome.storage.local.set({thecircle_recent_commands:this.recentCommands})}sortByRecent(e){const t=this.recentCommands.map(i=>e.find(a=>a.id===i)).filter(Boolean),s=e.filter(i=>!this.recentCommands.includes(i.id));return[...t,...s]}render(){var a;(a=this.container)==null||a.remove(),this.container=document.createElement("div"),this.container.id="thecircle-palette-root",this.shadowRoot=this.container.attachShadow({mode:"open"});const e=document.createElement("style");e.textContent=this.getStyles(),this.shadowRoot.appendChild(e);const t=document.createElement("div");t.className="glass-overlay",t.addEventListener("click",()=>this.hide()),this.shadowRoot.appendChild(t);const s=document.createElement("div"),i=this.savedPanelPosition&&this.savedPanelPosition.transform==="none";s.className=`glass-panel ${i?"glass-panel-enter-restored":"glass-panel-enter"} ${this.theme}`,this.savedPanelPosition&&(s.style.top=this.savedPanelPosition.top,s.style.left=this.savedPanelPosition.left,s.style.right=this.savedPanelPosition.right,s.style.transform=this.savedPanelPosition.transform),this.shadowRoot.appendChild(s),document.body.appendChild(this.container),this.renderCurrentView(!1,!0),setTimeout(()=>{s.classList.remove("glass-panel-enter"),s.classList.remove("glass-panel-enter-restored")},300)}renderCurrentView(e=!0,t=!1){if(!this.shadowRoot)return;const s=this.shadowRoot.querySelector(".glass-panel");if(!s)return;const i=s.getAttribute("data-view"),a=e&&i!==this.currentView;switch(s.setAttribute("data-view",this.currentView),a&&(s.classList.add("glass-view-transition"),setTimeout(()=>s.classList.remove("glass-view-transition"),200)),t||(this.currentView==="ai-result"?s.style.transform!=="none"&&(s.style.position="fixed",s.style.top="80px",s.style.left="auto",s.style.right="20px",s.style.transform="none"):this.currentView==="commands"&&(s.style.position="",s.style.top="",s.style.left="",s.style.right="",s.style.transform="")),this.currentView){case"commands":s.innerHTML=this.getCommandsViewHTML(),this.bindCommandsEvents(),this.renderCommands(),requestAnimationFrame(()=>{var o;const n=(o=this.shadowRoot)==null?void 0:o.querySelector(".glass-input");n==null||n.focus()});break;case"ai-result":s.innerHTML=this.getAIResultViewHTML(),this.bindAIResultEvents();break;case"settings":s.innerHTML=this.getSettingsViewHTML(),this.bindSettingsEvents();break;case"settings-menu":s.innerHTML=this.getMenuSettingsHTML(),this.bindMenuSettingsEvents();break;case"screenshot":s.innerHTML=this.getScreenshotViewHTML(),this.bindScreenshotViewEvents();break;case"browseTrail":s.innerHTML=this.getBrowseTrailViewHTML(),this.bindBrowseTrailEvents(),requestAnimationFrame(()=>{var o;const n=(o=this.shadowRoot)==null?void 0:o.querySelector(".glass-input");n==null||n.focus()});break;case"contextChat":s.innerHTML=this.getContextChatViewHTML(),this.bindContextChatEvents(),requestAnimationFrame(()=>{var o;const n=(o=this.shadowRoot)==null?void 0:o.querySelector(".glass-input");n==null||n.focus()});break}}getCommandsViewHTML(){var l,h,g,p,m,b,T,S,w,k,A,I,M,D,E,z,$,P;const e=this.activeCommand!==null,t=e&&["translate","summarize","explain","rewrite","codeExplain","summarizePage"].includes(((l=this.activeCommand)==null?void 0:l.action)||""),s=e&&["contextChat"].includes(((h=this.activeCommand)==null?void 0:h.action)||""),i=((g=this.aiResultData)==null?void 0:g.isLoading)??!1,a=((p=this.aiResultData)==null?void 0:p.resultType)==="translate",n=((b=(m=this.activeCommand)==null?void 0:m.id)==null?void 0:b.startsWith("saved_"))??!1;let o="搜索命令或直接提问...";e&&(s?o="输入内容后按回车...":a&&((T=this.aiResultData)!=null&&T.originalText)?o="":i?o="处理中...":o="");const r=a&&((S=this.aiResultData)!=null&&S.originalText)?this.aiResultData.originalText:"";return`
      <div class="glass-search glass-draggable">
        ${e?`
          <div class="glass-command-tag" data-action="${(w=this.activeCommand)==null?void 0:w.action}">
            <span class="glass-command-tag-icon">${((k=this.activeCommand)==null?void 0:k.icon)||""}</span>
            <span class="glass-command-tag-label">${this.escapeHtml(((A=this.activeCommand)==null?void 0:A.label)||"")}</span>
            <button class="glass-command-tag-close">&times;</button>
          </div>
        `:`
          <div class="glass-search-icon">${u.search}</div>
        `}
        <input
          type="text"
          class="glass-input"
          placeholder="${o}"
          value="${this.escapeHtml(r)}"
          autocomplete="off"
          spellcheck="false"
          ${t&&!s?"readonly":""}
        />
        <kbd class="glass-kbd">ESC</kbd>
      </div>
      <div class="glass-divider"></div>
      ${e&&this.aiResultData?this.getSourceInfoHTML(this.aiResultData):""}
      <div class="glass-body">
        ${e?`
          <div class="glass-ai-content-area">
            ${i&&!((I=this.aiResultData)!=null&&I.content)?this.getLoadingHTML():""}
            ${(M=this.aiResultData)!=null&&M.content?`<div class="glass-ai-content">${this.formatAIContent(this.aiResultData.content)}</div>`:""}
          </div>
        `:`
          <div class="glass-commands"></div>
          <div class="glass-minimized-section"></div>
          <div class="glass-recent-section"></div>
        `}
      </div>
      <div class="glass-footer">
        ${e?`
          <div class="glass-ai-footer-actions">
            <button class="glass-footer-btn glass-btn-stop" title="终止" style="display: ${i?"flex":"none"}">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <rect x="6" y="6" width="12" height="12" rx="2"></rect>
              </svg>
            </button>
            ${a?this.getTranslateLanguageSelectHTML(((D=this.aiResultData)==null?void 0:D.translateTargetLanguage)||this.config.preferredLanguage||"zh-CN"):""}
            ${a&&((E=this.aiResultData)!=null&&E.originalText)?`
              <button class="glass-footer-btn glass-btn-compare" title="对比原文">
                ${u.columns}
              </button>
            `:""}
            <button class="glass-footer-btn glass-btn-copy" title="复制" style="display: ${(z=this.aiResultData)!=null&&z.content?"flex":"none"}">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
                <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>
              </svg>
            </button>
            ${(($=this.activeCommand)==null?void 0:$.action)==="summarizePage"&&!n?`
              <button class="glass-footer-btn glass-btn-refresh" title="重新总结" style="display: ${i?"none":"flex"}">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                  <path d="M21 2v6h-6"></path>
                  <path d="M3 12a9 9 0 0 1 15-6.7L21 8"></path>
                  <path d="M3 22v-6h6"></path>
                  <path d="M21 12a9 9 0 0 1-15 6.7L3 16"></path>
                </svg>
              </button>
            `:""}
            ${n?"":`
            <button class="glass-footer-btn glass-btn-save" title="保存" style="display: ${(P=this.aiResultData)!=null&&P.content&&!i?"flex":"none"}">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"></path>
                <polyline points="17 21 17 13 7 13 7 21"></polyline>
                <polyline points="7 3 7 8 15 8"></polyline>
              </svg>
            </button>
            `}
          </div>
        `:`
          <div class="glass-hints">
            <span><kbd>↑</kbd><kbd>↓</kbd> 导航</span>
            <span><kbd>↵</kbd> 执行</span>
          </div>
        `}
        <div class="glass-brand">
          <span class="glass-logo">${u.logo}</span>
        </div>
      </div>
    `}bindCommandsEvents(){if(!this.shadowRoot)return;const e=this.shadowRoot.querySelector(".glass-input"),t=this.activeCommand!==null,s=this.shadowRoot.querySelector(".glass-search.glass-draggable");s&&s.addEventListener("mousedown",this.handleDragStart);const i=this.shadowRoot.querySelector(".glass-command-tag-close");if(i==null||i.addEventListener("click",a=>{a.stopPropagation(),this.clearActiveCommand()}),t){const a=this.shadowRoot.querySelector(".glass-btn-stop");a==null||a.addEventListener("click",()=>{var g,p;this.aiResultData&&(this.aiResultData.isLoading=!1),(p=(g=this.aiResultCallbacks)==null?void 0:g.onStop)==null||p.call(g),this.updateUnifiedContent()});const n=this.shadowRoot.querySelector(".glass-btn-copy");n==null||n.addEventListener("click",()=>{var g;(g=this.aiResultData)!=null&&g.content&&(navigator.clipboard.writeText(this.aiResultData.content),this.showCopyFeedback(n))});const o=this.shadowRoot.querySelector(".glass-btn-compare");o==null||o.addEventListener("click",()=>{this.toggleCompareMode()});const r=this.shadowRoot.querySelector(".glass-lang-select");r==null||r.addEventListener("change",()=>{var g,p;this.aiResultData&&(this.currentStreamKey=`stream-${Date.now()}-${Math.random().toString(36).substr(2,9)}`,this.aiResultData.streamKey=this.currentStreamKey,this.aiResultData.translateTargetLanguage=r.value,this.aiResultData.isLoading=!0,this.aiResultData.content="",this.updateUnifiedContent(),(p=(g=this.aiResultCallbacks)==null?void 0:g.onTranslateLanguageChange)==null||p.call(g,r.value))});const l=this.shadowRoot.querySelector(".glass-btn-refresh");l==null||l.addEventListener("click",()=>{var g,p;(p=(g=this.aiResultCallbacks)==null?void 0:g.onRefresh)==null||p.call(g)});const h=this.shadowRoot.querySelector(".glass-btn-save");h==null||h.addEventListener("click",()=>{this.saveCurrentTask(h)})}e==null||e.addEventListener("input",()=>{t?this.activeCommandInput=e.value:(this.searchQuery=e.value.toLowerCase().trim(),this.filterCommands())}),e==null||e.addEventListener("keydown",a=>{if(!a.isComposing){if(t){a.key==="Escape"&&(a.preventDefault(),this.clearActiveCommand());return}switch(a.key){case"ArrowDown":a.preventDefault(),this.selectNext();break;case"ArrowUp":a.preventDefault(),this.selectPrev();break;case"Enter":a.preventDefault(),this.executeSelected();break;case"Escape":a.preventDefault(),this.hide();break;case"Tab":a.preventDefault(),a.shiftKey?this.selectPrev():this.selectNext();break}}}),t||e==null||e.addEventListener("keydown",a=>{if(!a.isComposing&&a.key>="1"&&a.key<="9"&&!this.searchQuery){const n=parseInt(a.key)-1;n<this.filteredItems.length&&(a.preventDefault(),this.selectedIndex=n,this.executeSelected())}})}clearActiveCommand(){var e;if(this.aiResultData&&this.aiResultData.isLoading&&this.activeCommand){this.minimizeToBackground();return}(e=this.aiResultCallbacks)!=null&&e.onStop&&this.aiResultCallbacks.onStop(),this.currentStreamKey=null,this.activeCommand=null,this.activeCommandInput="",this.aiResultData=null,this.aiResultCallbacks=null,this.searchQuery="",this.renderCurrentView(!0,!0)}minimizeToBackground(){if(!this.aiResultData)return;if(this.aiResultData.actionType){const t=this.minimizedTasks.findIndex(s=>s.actionType===this.aiResultData.actionType);t!==-1&&this.minimizedTasks.splice(t,1)}const e={id:`task-${++this.minimizedTaskIdCounter}`,title:this.aiResultData.title,content:this.aiResultData.content,originalText:this.aiResultData.originalText,resultType:this.aiResultData.resultType,translateTargetLanguage:this.aiResultData.translateTargetLanguage,iconHtml:this.aiResultData.iconHtml,isLoading:this.aiResultData.isLoading,minimizedAt:Date.now(),streamKey:this.aiResultData.streamKey,callbacks:this.aiResultCallbacks||void 0,actionType:this.aiResultData.actionType,sourceUrl:this.aiResultData.sourceUrl,sourceTitle:this.aiResultData.sourceTitle,createdAt:this.aiResultData.createdAt||Date.now()};this.minimizedTasks.push(e),this.activeCommand=null,this.activeCommandInput="",this.aiResultData=null,this.aiResultCallbacks=null,this.searchQuery="",this.renderCurrentView(!0,!0)}async saveCurrentTask(e){var t;if(!(!this.aiResultData||!this.aiResultData.content))try{await ae({title:this.aiResultData.title,content:this.aiResultData.content,originalText:this.aiResultData.originalText,resultType:this.aiResultData.resultType,actionType:this.aiResultData.actionType||"unknown",sourceUrl:this.aiResultData.sourceUrl||window.location.href,sourceTitle:this.aiResultData.sourceTitle||document.title,translateTargetLanguage:this.aiResultData.translateTargetLanguage,createdAt:this.aiResultData.createdAt||Date.now()});const s=((t=this.config.history)==null?void 0:t.maxSaveCount)||y.maxSaveCount;await Y(s),await this.loadRecentSavedTasks(),this.showSaveFeedback(e)}catch(s){console.error("Failed to save task:",s)}}showSaveFeedback(e){const t=e.innerHTML;e.innerHTML=`
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <polyline points="20 6 9 17 4 12"></polyline>
      </svg>
    `,e.classList.add("saved"),setTimeout(()=>{e.innerHTML=t,e.classList.remove("saved")},1500)}updateUnifiedContent(){if(!this.shadowRoot||!this.aiResultData)return;const e=this.shadowRoot.querySelector(".glass-ai-content-area"),t=this.shadowRoot.querySelector(".glass-ai-footer-actions");if(e&&(this.aiResultData.isLoading&&!this.aiResultData.content?e.innerHTML=this.getLoadingHTML():this.aiResultData.content&&(e.innerHTML=`<div class="glass-ai-content">${this.formatAIContent(this.aiResultData.content)}</div>`)),t){const i=t.querySelector(".glass-btn-stop"),a=t.querySelector(".glass-btn-copy"),n=t.querySelector(".glass-btn-refresh"),o=t.querySelector(".glass-btn-save");i&&(i.style.display=this.aiResultData.isLoading?"flex":"none"),a&&(a.style.display=this.aiResultData.content?"flex":"none"),n&&(n.style.display=this.aiResultData.isLoading?"none":"flex"),o&&(o.style.display=this.aiResultData.content&&!this.aiResultData.isLoading?"flex":"none")}const s=this.shadowRoot.querySelector(".glass-input");s&&!this.aiResultData.isLoading&&(s.placeholder="")}getAIResultViewHTML(){const e=this.aiResultData;if(!e)return"";const t=e.resultType==="translate"&&e.originalText,s=e.actionType==="summarizePage";return`
      <div class="glass-header glass-draggable">
        <button class="glass-back-btn">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M19 12H5M12 19l-7-7 7-7"/>
          </svg>
        </button>
        <span class="glass-header-title">${this.escapeHtml(e.title)}</span>
        <div class="glass-header-actions">
          ${t?this.getTranslateLanguageSelectHTML(e.translateTargetLanguage||"zh-CN"):""}
          ${t?`
            <button class="glass-header-btn glass-btn-compare" title="对比原文">
              ${u.columns}
            </button>
          `:""}
          ${s&&!e.isLoading?`
            <button class="glass-header-btn glass-btn-refresh" title="重新总结">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M21 2v6h-6"></path>
                <path d="M3 12a9 9 0 0 1 15-6.7L21 8"></path>
                <path d="M3 22v-6h6"></path>
                <path d="M21 12a9 9 0 0 1-15 6.7L3 16"></path>
              </svg>
            </button>
          `:""}
          <button class="glass-header-btn glass-btn-copy" title="复制">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
              <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>
            </svg>
          </button>
          <button class="glass-header-btn glass-btn-stop" title="终止" style="display: ${e.isLoading?"flex":"none"}">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <rect x="6" y="6" width="12" height="12" rx="2"></rect>
            </svg>
          </button>
          <button class="glass-minimize-btn" title="最小化">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <line x1="5" y1="12" x2="19" y2="12"></line>
            </svg>
          </button>
        </div>
      </div>
      <div class="glass-divider"></div>
      ${this.getSourceInfoHTML(e)}
      <div class="glass-body glass-ai-result-body">
        <div class="glass-ai-content" data-compare="false">
          ${e.isLoading&&!e.content?this.getLoadingHTML():this.formatAIContent(e.content)}
        </div>
      </div>
    `}getSourceInfoHTML(e){const t=e.actionType==="summarizePage",s=e.resultType==="translate";if(!t&&!s||!e.sourceUrl&&!e.sourceTitle&&!e.originalText)return"";let i="",a="";if(t){const n=e.sourceTitle||(e.sourceUrl?new URL(e.sourceUrl).hostname:"");e.sourceUrl?i=`<a class="glass-source-link" href="${this.escapeHtml(e.sourceUrl)}" target="_blank" title="${this.escapeHtml(e.sourceUrl)}">${this.escapeHtml(n)}</a>`:n&&(i=`<span class="glass-source-title">${this.escapeHtml(n)}</span>`)}else if(s&&e.sourceUrl)try{const n=new URL(e.sourceUrl).hostname;i=`<span class="glass-source-title">${this.escapeHtml(n)}</span>`}catch{}return e.createdAt&&(a=this.formatTimeAgo(e.createdAt)),!i&&!a?"":`
      <div class="glass-source-info">
        <div class="glass-source-icon">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path>
            <polyline points="15 3 21 3 21 9"></polyline>
            <line x1="10" y1="14" x2="21" y2="3"></line>
          </svg>
        </div>
        <div class="glass-source-content">
          ${i}
          ${a?`<span class="glass-source-meta">${a}</span>`:""}
        </div>
      </div>
    `}getTranslateLanguageSelectHTML(e){return`<select class="glass-lang-select">${[{value:"zh-CN",label:"简体中文"},{value:"zh-TW",label:"繁体中文"},{value:"en",label:"English"},{value:"ja",label:"日本語"},{value:"ko",label:"한국어"},{value:"es",label:"Español"},{value:"fr",label:"Français"},{value:"de",label:"Deutsch"}].map(({value:i,label:a})=>`<option value="${i}"${i===e?" selected":""}>${a}</option>`).join("")}</select>`}getLoadingHTML(){return`
      <div class="glass-loading">
        <div class="glass-spinner"></div>
        <span>正在思考...</span>
      </div>
    `}formatAIContent(e){return e?e.replace(/\n/g,"<br>").replace(/\*\*(.*?)\*\*/g,"<strong>$1</strong>").replace(/\*(.*?)\*/g,"<em>$1</em>").replace(/`(.*?)`/g,"<code>$1</code>"):""}bindAIResultEvents(){if(!this.shadowRoot)return;const e=this.shadowRoot.querySelector(".glass-back-btn");e==null||e.addEventListener("click",()=>{this.aiResultData&&this.minimize(),this.currentView="commands",this.viewStack=[],this.aiResultData=null,this.aiResultCallbacks=null,this.renderCurrentView(!0,!0)});const t=this.shadowRoot.querySelector(".glass-minimize-btn");t==null||t.addEventListener("click",l=>{l.stopPropagation(),this.minimize()});const s=this.shadowRoot.querySelector(".glass-draggable");s&&s.addEventListener("mousedown",this.handleDragStart);const i=this.shadowRoot.querySelector(".glass-btn-refresh");i==null||i.addEventListener("click",()=>{var l,h;(h=(l=this.aiResultCallbacks)==null?void 0:l.onRefresh)==null||h.call(l)});const a=this.shadowRoot.querySelector(".glass-btn-stop");a==null||a.addEventListener("click",()=>{var l,h;this.aiResultData&&(this.aiResultData.isLoading=!1),(h=(l=this.aiResultCallbacks)==null?void 0:l.onStop)==null||h.call(l),this.updateAIResultContent()});const n=this.shadowRoot.querySelector(".glass-btn-copy");n==null||n.addEventListener("click",()=>{var l;(l=this.aiResultData)!=null&&l.content&&(navigator.clipboard.writeText(this.aiResultData.content),this.showCopyFeedback(n))});const o=this.shadowRoot.querySelector(".glass-btn-compare");o==null||o.addEventListener("click",()=>{this.toggleCompareMode()});const r=this.shadowRoot.querySelector(".glass-lang-select");r==null||r.addEventListener("change",()=>{var l,h;this.aiResultData&&(this.currentStreamKey=`stream-${Date.now()}-${Math.random().toString(36).substr(2,9)}`,this.aiResultData.streamKey=this.currentStreamKey,this.aiResultData.translateTargetLanguage=r.value,this.aiResultData.isLoading=!0,this.aiResultData.content="",this.updateAIResultContent(),(h=(l=this.aiResultCallbacks)==null?void 0:l.onTranslateLanguageChange)==null||h.call(l,r.value))}),document.removeEventListener("keydown",this.handleAIResultKeydown),document.addEventListener("keydown",this.handleAIResultKeydown)}minimize(){if(!this.aiResultData)return;if(this.aiResultData.actionType==="summarizePage"){const t=this.minimizedTasks.findIndex(s=>s.actionType==="summarizePage");t!==-1&&this.minimizedTasks.splice(t,1)}const e={id:`task-${++this.minimizedTaskIdCounter}`,title:this.aiResultData.title,content:this.aiResultData.content,originalText:this.aiResultData.originalText,resultType:this.aiResultData.resultType,translateTargetLanguage:this.aiResultData.translateTargetLanguage,iconHtml:this.aiResultData.iconHtml,isLoading:this.aiResultData.isLoading,minimizedAt:Date.now(),streamKey:this.aiResultData.streamKey,callbacks:this.aiResultCallbacks||void 0,actionType:this.aiResultData.actionType,sourceUrl:this.aiResultData.sourceUrl,sourceTitle:this.aiResultData.sourceTitle,createdAt:this.aiResultData.createdAt||Date.now()};this.minimizedTasks.push(e),this.aiResultData=null,this.aiResultCallbacks=null,this.hide()}restoreMinimizedTask(e){const t=this.minimizedTasks.findIndex(i=>i.id===e);if(t===-1)return;const s=this.minimizedTasks[t];this.minimizedTasks.splice(t,1),this.aiResultData={title:s.title,content:s.content,originalText:s.originalText,isLoading:s.isLoading,resultType:s.resultType,translateTargetLanguage:s.translateTargetLanguage,iconHtml:s.iconHtml,streamKey:s.streamKey,actionType:s.actionType,sourceUrl:s.sourceUrl,sourceTitle:s.sourceTitle,createdAt:s.createdAt},s.isLoading&&s.streamKey&&(this.currentStreamKey=s.streamKey),this.activeCommand={id:s.actionType||"unknown",label:s.title,icon:s.iconHtml||"",action:s.actionType||"unknown",enabled:!0,order:0},this.aiResultCallbacks={...s.callbacks,onStop:()=>V()},this.currentView="commands",this.viewStack=[],this.renderCurrentView(!0,!0)}dismissMinimizedTask(e){const t=this.minimizedTasks.findIndex(i=>i.id===e);if(t===-1)return;const s=this.minimizedTasks[t];this.minimizedTasks.splice(t,1),s.streamKey&&this.currentStreamKey===s.streamKey&&(this.currentStreamKey=null),this.currentView==="commands"&&this.renderMinimizedTasks()}getDefaultMinimizedIcon(){return`<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <circle cx="12" cy="12" r="10"></circle>
      <path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"></path>
      <line x1="12" y1="17" x2="12.01" y2="17"></line>
    </svg>`}updateAIResultContent(){if(!this.shadowRoot||!this.aiResultData)return;const e=this.shadowRoot.querySelector(".glass-ai-content"),t=this.shadowRoot.querySelector(".glass-btn-stop");e&&(e.getAttribute("data-compare")==="true"&&this.aiResultData.originalText?e.innerHTML=`
          <div class="glass-compare-view">
            <div class="glass-compare-item">
              <div class="glass-compare-label">原文</div>
              <div class="glass-compare-content">${this.formatAIContent(this.aiResultData.originalText)}</div>
            </div>
            <div class="glass-compare-divider"></div>
            <div class="glass-compare-item">
              <div class="glass-compare-label">译文</div>
              <div class="glass-compare-content">${this.aiResultData.isLoading&&!this.aiResultData.content?this.getLoadingHTML():this.formatAIContent(this.aiResultData.content)}</div>
            </div>
          </div>
        `:e.innerHTML=this.aiResultData.isLoading&&!this.aiResultData.content?this.getLoadingHTML():this.formatAIContent(this.aiResultData.content)),t&&(t.style.display=this.aiResultData.isLoading?"flex":"none")}toggleCompareMode(){if(!this.shadowRoot)return;const e=this.shadowRoot.querySelector(".glass-ai-content");if(e){const t=e.getAttribute("data-compare")==="true";e.setAttribute("data-compare",t?"false":"true");const s=this.shadowRoot.querySelector(".glass-panel");s==null||s.classList.toggle("glass-panel-wide",!t),this.updateAIResultContent()}}showCopyFeedback(e){const t=e.innerHTML;e.innerHTML=`
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <polyline points="20 6 9 17 4 12"></polyline>
      </svg>
    `,e.classList.add("copied"),setTimeout(()=>{e.innerHTML=t,e.classList.remove("copied")},1500)}getSettingsViewHTML(){const e=this.tempConfig||this.config,t=e.apiProvider==="custom",s=e.screenshot||f,i=e.history||y;return`
      <div class="glass-search glass-draggable">
        <div class="glass-command-tag" data-action="settings">
          <span class="glass-command-tag-icon">${u.settings}</span>
          <span class="glass-command-tag-label">设置</span>
          <button class="glass-command-tag-close">&times;</button>
        </div>
        <input
          type="text"
          class="glass-input"
          placeholder=""
          autocomplete="off"
          spellcheck="false"
          readonly
        />
        <kbd class="glass-kbd">ESC</kbd>
      </div>
      <div class="glass-divider"></div>
      <div class="glass-body glass-settings-body">
        <div class="glass-settings-flat">
          <!-- 外观 -->
          <div class="glass-settings-section">
            <div class="glass-settings-section-title">外观</div>
            <div class="glass-form-group">
              <label class="glass-form-label">主题</label>
              <select class="glass-select" id="theme-select">
                <option value="system"${e.theme==="system"?" selected":""}>跟随系统</option>
                <option value="dark"${e.theme==="dark"?" selected":""}>深色</option>
                <option value="light"${e.theme==="light"?" selected":""}>浅色</option>
              </select>
            </div>
            <div class="glass-form-group">
              <label class="glass-form-label">弹出位置</label>
              <select class="glass-select" id="popover-position-select">
                <option value="above"${e.popoverPosition==="above"?" selected":""}>选中文本上方</option>
                <option value="below"${e.popoverPosition==="below"?" selected":""}>选中文本下方</option>
              </select>
            </div>
          </div>

          <!-- 语言 -->
          <div class="glass-settings-section">
            <div class="glass-settings-section-title">语言</div>
            <div class="glass-form-group">
              <label class="glass-form-label">翻译目标语言</label>
              <select class="glass-select" id="translate-lang-select">
                <option value="zh-CN"${e.preferredLanguage==="zh-CN"?" selected":""}>简体中文</option>
                <option value="zh-TW"${e.preferredLanguage==="zh-TW"?" selected":""}>繁体中文</option>
                <option value="en"${e.preferredLanguage==="en"?" selected":""}>English</option>
                <option value="ja"${e.preferredLanguage==="ja"?" selected":""}>日本語</option>
                <option value="ko"${e.preferredLanguage==="ko"?" selected":""}>한국어</option>
                <option value="es"${e.preferredLanguage==="es"?" selected":""}>Español</option>
                <option value="fr"${e.preferredLanguage==="fr"?" selected":""}>Français</option>
                <option value="de"${e.preferredLanguage==="de"?" selected":""}>Deutsch</option>
              </select>
            </div>
            <div class="glass-form-group">
              <label class="glass-form-label">总结输出语言</label>
              <select class="glass-select" id="summary-lang-select">
                <option value="auto"${e.summaryLanguage==="auto"?" selected":""}>自动检测</option>
                <option value="zh-CN"${e.summaryLanguage==="zh-CN"?" selected":""}>简体中文</option>
                <option value="zh-TW"${e.summaryLanguage==="zh-TW"?" selected":""}>繁体中文</option>
                <option value="en"${e.summaryLanguage==="en"?" selected":""}>English</option>
                <option value="ja"${e.summaryLanguage==="ja"?" selected":""}>日本語</option>
              </select>
            </div>
          </div>

          <!-- AI 服务 -->
          <div class="glass-settings-section">
            <div class="glass-settings-section-title">AI 服务</div>
            <div class="glass-form-group">
              <label class="glass-form-label">服务商</label>
              <select class="glass-select" id="api-provider-select">
                <option value="groq"${e.apiProvider==="groq"?" selected":""}>Groq (免费)</option>
                <option value="openai"${e.apiProvider==="openai"?" selected":""}>OpenAI</option>
                <option value="anthropic"${e.apiProvider==="anthropic"?" selected":""}>Anthropic</option>
                <option value="gemini"${e.apiProvider==="gemini"?" selected":""}>Google Gemini</option>
                <option value="custom"${e.apiProvider==="custom"?" selected":""}>自定义</option>
              </select>
              <span class="glass-form-hint" id="api-key-hint">${this.getAPIKeyHint(e.apiProvider)}</span>
            </div>
            <div class="glass-form-group">
              <label class="glass-form-label">API Key</label>
              <input type="password" class="glass-input-field" id="api-key-input" value="${e.apiKey||""}" placeholder="输入 API Key">
            </div>
            <div class="glass-form-group" id="custom-url-group" style="display: ${t?"block":"none"}">
              <label class="glass-form-label">API URL</label>
              <input type="text" class="glass-input-field" id="custom-url-input" value="${e.customApiUrl||""}" placeholder="https://api.example.com/v1/chat/completions">
            </div>
            <div class="glass-form-group" id="custom-model-group" style="display: ${t?"block":"none"}">
              <label class="glass-form-label">模型名称</label>
              <input type="text" class="glass-input-field" id="custom-model-input" value="${e.customModel||""}" placeholder="gpt-4">
            </div>
            <div class="glass-form-group glass-form-toggle">
              <label class="glass-form-label">流式传输</label>
              <label class="glass-toggle">
                <input type="checkbox" id="streaming-toggle" ${e.useStreaming?"checked":""}>
                <span class="glass-toggle-slider"></span>
              </label>
            </div>
          </div>

          <!-- 截图 -->
          <div class="glass-settings-section">
            <div class="glass-settings-section-title">截图</div>
            <div class="glass-form-group glass-form-toggle">
              <label class="glass-form-label">保存到文件</label>
              <label class="glass-toggle">
                <input type="checkbox" id="save-to-file" ${s.saveToFile?"checked":""}>
                <span class="glass-toggle-slider"></span>
              </label>
            </div>
            <div class="glass-form-group glass-form-toggle">
              <label class="glass-form-label">复制到剪贴板</label>
              <label class="glass-toggle">
                <input type="checkbox" id="copy-to-clipboard" ${s.copyToClipboard?"checked":""}>
                <span class="glass-toggle-slider"></span>
              </label>
            </div>
            <div class="glass-form-group glass-form-toggle">
              <label class="glass-form-label">AI 分析</label>
              <label class="glass-toggle">
                <input type="checkbox" id="enable-ai" ${s.enableAI?"checked":""}>
                <span class="glass-toggle-slider"></span>
              </label>
            </div>
            <div class="glass-form-group">
              <label class="glass-form-label">默认 AI 操作</label>
              <select class="glass-select" id="default-ai-action">
                <option value="none"${s.defaultAIAction==="none"?" selected":""}>无</option>
                <option value="ask"${s.defaultAIAction==="ask"?" selected":""}>询问</option>
                <option value="describe"${s.defaultAIAction==="describe"?" selected":""}>描述</option>
              </select>
            </div>
          </div>

          <!-- 历史记录 -->
          <div class="glass-settings-section">
            <div class="glass-settings-section-title">历史记录</div>
            <div class="glass-form-group">
              <label class="glass-form-label">最大保存数量</label>
              <select class="glass-select" id="history-max-count">
                <option value="50" ${i.maxSaveCount===50?"selected":""}>50 条</option>
                <option value="100" ${i.maxSaveCount===100?"selected":""}>100 条</option>
                <option value="200" ${i.maxSaveCount===200?"selected":""}>200 条</option>
                <option value="500" ${i.maxSaveCount===500?"selected":""}>500 条</option>
              </select>
              <span class="glass-form-hint">超过此数量时，最旧的记录将被自动删除</span>
            </div>
            <div class="glass-form-group">
              <label class="glass-form-label">面板显示数量</label>
              <select class="glass-select" id="history-display-count">
                <option value="5" ${i.panelDisplayCount===5?"selected":""}>5 条</option>
                <option value="10" ${i.panelDisplayCount===10?"selected":""}>10 条</option>
                <option value="15" ${i.panelDisplayCount===15?"selected":""}>15 条</option>
                <option value="20" ${i.panelDisplayCount===20?"selected":""}>20 条</option>
              </select>
              <span class="glass-form-hint">命令面板中显示的最近记录数量</span>
            </div>
            <div class="glass-form-group">
              <button id="clear-history" class="glass-btn glass-btn-danger">清空所有历史记录</button>
            </div>
          </div>

          <!-- 重置 -->
          <div class="glass-settings-section">
            <div class="glass-form-group">
              <button class="glass-btn glass-btn-reset">重置为默认设置</button>
            </div>
          </div>
        </div>
      </div>
      <div class="glass-footer glass-settings-footer">
        <div class="glass-settings-footer-actions">
          <button class="glass-btn glass-btn-cancel">取消</button>
          <button class="glass-btn glass-btn-primary glass-btn-save">保存</button>
        </div>
      </div>
    `}bindSettingsEvents(){if(!this.shadowRoot||!this.tempConfig)return;const e=this.tempConfig,t=e.screenshot||{...f},s=e.history||{...y},i=this.shadowRoot.querySelector(".glass-search.glass-draggable");i&&i.addEventListener("mousedown",this.handleDragStart);const a=()=>{this.settingsChanged=!0},n=this.shadowRoot.querySelector(".glass-command-tag-close");n==null||n.addEventListener("click",()=>this.cancelSettings());const o=this.shadowRoot.querySelector(".glass-btn-cancel");o==null||o.addEventListener("click",()=>this.cancelSettings());const r=this.shadowRoot.querySelector(".glass-btn-save");r==null||r.addEventListener("click",()=>this.saveSettings());const l=this.shadowRoot.querySelector("#theme-select");l==null||l.addEventListener("change",()=>{var U;e.theme=l.value,a(),this.updateTheme(e.theme);const v=(U=this.shadowRoot)==null?void 0:U.querySelector(".glass-panel");v==null||v.classList.remove("dark","light"),v==null||v.classList.add(this.theme)});const h=this.shadowRoot.querySelector("#popover-position-select");h==null||h.addEventListener("change",()=>{e.popoverPosition=h.value,a()});const g=this.shadowRoot.querySelector("#translate-lang-select");g==null||g.addEventListener("change",()=>{e.preferredLanguage=g.value,a()});const p=this.shadowRoot.querySelector("#summary-lang-select");p==null||p.addEventListener("change",()=>{e.summaryLanguage=p.value,a()});const m=this.shadowRoot.querySelector("#api-provider-select"),b=this.shadowRoot.querySelector("#custom-url-group"),T=this.shadowRoot.querySelector("#custom-model-group"),S=this.shadowRoot.querySelector("#api-key-hint");m==null||m.addEventListener("change",()=>{const v=m.value,U=v==="custom";b&&(b.style.display=U?"block":"none"),T&&(T.style.display=U?"block":"none"),S&&(S.textContent=this.getAPIKeyHint(v)),e.apiProvider=v,a()});const w=this.shadowRoot.querySelector("#api-key-input");w==null||w.addEventListener("input",()=>{e.apiKey=w.value||void 0,a()});const k=this.shadowRoot.querySelector("#custom-url-input");k==null||k.addEventListener("input",()=>{e.customApiUrl=k.value||void 0,a()});const A=this.shadowRoot.querySelector("#custom-model-input");A==null||A.addEventListener("input",()=>{e.customModel=A.value||void 0,a()});const I=this.shadowRoot.querySelector("#streaming-toggle");I==null||I.addEventListener("change",()=>{e.useStreaming=I.checked,a()});const M=this.shadowRoot.querySelector("#save-to-file");M==null||M.addEventListener("change",()=>{t.saveToFile=M.checked,e.screenshot=t,a()});const D=this.shadowRoot.querySelector("#copy-to-clipboard");D==null||D.addEventListener("change",()=>{t.copyToClipboard=D.checked,e.screenshot=t,a()});const E=this.shadowRoot.querySelector("#enable-ai");E==null||E.addEventListener("change",()=>{t.enableAI=E.checked,e.screenshot=t,a()});const z=this.shadowRoot.querySelector("#default-ai-action");z==null||z.addEventListener("change",()=>{t.defaultAIAction=z.value,e.screenshot=t,a()});const $=this.shadowRoot.querySelector("#history-max-count");$==null||$.addEventListener("change",()=>{s.maxSaveCount=parseInt($.value,10),e.history=s,a()});const P=this.shadowRoot.querySelector("#history-display-count");P==null||P.addEventListener("change",()=>{s.panelDisplayCount=parseInt(P.value,10),e.history=s,a()});const J=this.shadowRoot.querySelector("#clear-history");J==null||J.addEventListener("click",async()=>{if(confirm("确定要清空所有历史记录吗？此操作不可撤销。")){const{clearAllTasks:v}=await Promise.resolve().then(()=>Se);await v(),this.recentSavedTasks=[],this.showToast("历史记录已清空")}});const Z=this.shadowRoot.querySelector(".glass-btn-reset");Z==null||Z.addEventListener("click",async()=>{confirm("确定要重置所有设置吗？")&&(await se(C),await j(H),this.config={...C},this.tempConfig=JSON.parse(JSON.stringify(C)),this.settingsMenuItems=[...H],this.settingsChanged=!1,this.showToast("已重置为默认设置"),this.renderCurrentView(!0,!0))}),this.shadowRoot.addEventListener("keydown",v=>{v.key==="Escape"&&(v.preventDefault(),this.cancelSettings())})}cancelSettings(){var e,t;if(this.settingsChanged&&((e=this.tempConfig)==null?void 0:e.theme)!==this.config.theme){this.updateTheme(this.config.theme);const s=(t=this.shadowRoot)==null?void 0:t.querySelector(".glass-panel");s==null||s.classList.remove("dark","light"),s==null||s.classList.add(this.theme)}this.tempConfig=null,this.settingsChanged=!1,this.activeCommand=null,this.currentView="commands",this.viewStack=[],this.renderCurrentView(!0,!0)}async saveSettings(){this.tempConfig&&(await se(this.tempConfig),this.config=this.tempConfig,this.tempConfig.history&&(await Y(this.tempConfig.history.maxSaveCount),await this.loadRecentSavedTasks()),this.tempConfig=null,this.settingsChanged=!1,this.showToast("设置已保存"),this.activeCommand=null,this.currentView="commands",this.viewStack=[],this.renderCurrentView(!0,!0))}getAPIKeyHint(e){return e==="groq"?"使用 Groq 免费服务无需配置 API Key":e==="custom"?"如果你的 API 需要认证，请填写 API Key":`请填写你的 ${e.toUpperCase()} API Key`}showToast(e){var s;if(!this.shadowRoot)return;(s=this.shadowRoot.querySelector(".glass-toast"))==null||s.remove();const t=document.createElement("div");t.className="glass-toast",t.textContent=e,this.shadowRoot.appendChild(t),setTimeout(()=>t.classList.add("show"),10),setTimeout(()=>{t.classList.remove("show"),setTimeout(()=>t.remove(),200)},2e3)}getMenuSettingsHTML(){return`
      <div class="glass-header">
        <button class="glass-back-btn">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M19 12H5M12 19l-7-7 7-7"/>
          </svg>
        </button>
        <span class="glass-header-title">菜单管理</span>
        <div class="glass-header-actions"></div>
      </div>
      <div class="glass-divider"></div>
      <div class="glass-body">
        <div class="glass-menu-list" id="menu-list">
          ${[...this.settingsMenuItems.length>0?this.settingsMenuItems:H].sort((s,i)=>s.order-i.order).map(s=>this.getMenuItemHTML(s)).join("")}
        </div>
      </div>
      <div class="glass-footer">
        <button class="glass-btn glass-btn-add">+ 添加自定义菜单项</button>
        <div class="glass-brand">
          <span class="glass-logo">${u.logo}</span>
        </div>
      </div>
    `}getMenuItemHTML(e){const t=e.isCustom;return`
      <div class="glass-menu-item" data-id="${e.id}" draggable="true">
        <span class="glass-menu-drag">⋮⋮</span>
        <span class="glass-menu-icon">${e.customIcon||e.icon}</span>
        <span class="glass-menu-label">${e.customLabel||e.label}</span>
        ${t?`
          <button class="glass-menu-btn glass-menu-edit" data-id="${e.id}" title="编辑">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M12 3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/>
              <path d="M18.375 2.625a1 1 0 0 1 3 3l-9.013 9.014a2 2 0 0 1-.853.505l-2.873.84a.5.5 0 0 1-.62-.62l.84-2.873a2 2 0 0 1 .506-.852z"/>
            </svg>
          </button>
          <button class="glass-menu-btn glass-menu-delete" data-id="${e.id}" title="删除">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/>
              <path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/>
            </svg>
          </button>
        `:""}
        <label class="glass-toggle glass-toggle-small">
          <input type="checkbox" data-id="${e.id}" ${e.enabled?"checked":""}>
          <span class="glass-toggle-slider"></span>
        </label>
      </div>
    `}bindMenuSettingsEvents(){if(!this.shadowRoot)return;const e=this.shadowRoot.querySelector(".glass-back-btn");e==null||e.addEventListener("click",()=>this.popView()),this.shadowRoot.querySelectorAll(".glass-toggle input").forEach(s=>{s.addEventListener("change",async i=>{const a=i.target,n=a.dataset.id,o=this.settingsMenuItems.find(r=>r.id===n);o&&(o.enabled=a.checked,await j(this.settingsMenuItems),this.showToast("菜单项已更新"))})}),this.shadowRoot.querySelectorAll(".glass-menu-delete").forEach(s=>{s.addEventListener("click",async()=>{const i=s.dataset.id;i&&(this.settingsMenuItems=this.settingsMenuItems.filter(a=>a.id!==i),await j(this.settingsMenuItems),this.renderCurrentView(!0,!0),this.showToast("菜单项已删除"))})});const t=this.shadowRoot.querySelector(".glass-btn-add");t==null||t.addEventListener("click",()=>{this.showToast("请在设置页面添加自定义菜单项")}),this.setupMenuDragDrop(),this.shadowRoot.addEventListener("keydown",s=>{s.key==="Escape"&&(s.preventDefault(),this.popView())})}setupMenuDragDrop(){if(!this.shadowRoot)return;const e=this.shadowRoot.querySelector("#menu-list");if(!e)return;let t=null;e.querySelectorAll(".glass-menu-item").forEach(s=>{const i=s;i.addEventListener("dragstart",()=>{t=i,setTimeout(()=>i.classList.add("dragging"),0)}),i.addEventListener("dragend",async()=>{i.classList.remove("dragging"),t=null,e.querySelectorAll(".glass-menu-item").forEach((n,o)=>{const r=n.dataset.id,l=this.settingsMenuItems.find(h=>h.id===r);l&&(l.order=o)}),await j(this.settingsMenuItems)}),i.addEventListener("dragover",a=>{a.preventDefault(),i.classList.add("drag-over")}),i.addEventListener("dragleave",()=>{i.classList.remove("drag-over")}),i.addEventListener("drop",a=>{if(a.preventDefault(),i.classList.remove("drag-over"),t&&t!==i){const n=i.getBoundingClientRect(),o=n.top+n.height/2;a.clientY<o?e.insertBefore(t,i):e.insertBefore(t,i.nextSibling)}})})}getScreenshotViewHTML(){var e;return`
      <div class="glass-search glass-draggable">
        <div class="glass-command-tag" data-action="screenshot">
          <span class="glass-command-tag-icon">${u.screenshot}</span>
          <span class="glass-command-tag-label">截图</span>
          <button class="glass-command-tag-close">&times;</button>
        </div>
        <input
          type="text"
          class="glass-input"
          placeholder=""
          autocomplete="off"
          spellcheck="false"
          readonly
        />
        <kbd class="glass-kbd">ESC</kbd>
      </div>
      <div class="glass-divider"></div>
      <div class="glass-body glass-screenshot-body">
        <div class="glass-screenshot-preview">
          <img src="${((e=this.screenshotData)==null?void 0:e.dataUrl)||""}" alt="Screenshot" />
        </div>
        <div class="glass-screenshot-content">
          ${this.getScreenshotContentHTML()}
        </div>
      </div>
      <div class="glass-footer">
        <div class="glass-screenshot-actions">
          <button class="glass-btn glass-btn-save">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
              <polyline points="7 10 12 15 17 10"/>
              <line x1="12" y1="15" x2="12" y2="3"/>
            </svg>
            保存
          </button>
          <button class="glass-btn glass-btn-copy-img">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
              <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>
            </svg>
            复制
          </button>
          <button class="glass-btn glass-btn-ask">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <circle cx="12" cy="12" r="10"></circle>
              <path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"></path>
              <line x1="12" y1="17" x2="12.01" y2="17"></line>
            </svg>
            询问AI
          </button>
          <button class="glass-btn glass-btn-describe">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
              <polyline points="14 2 14 8 20 8"></polyline>
              <line x1="16" y1="13" x2="8" y2="13"></line>
              <line x1="16" y1="17" x2="8" y2="17"></line>
            </svg>
            描述
          </button>
        </div>
        <div class="glass-brand">
          <span class="glass-logo">${u.logo}</span>
        </div>
      </div>
    `}getScreenshotContentHTML(){return this.screenshotData?this.screenshotData.isLoading?`
        <div class="glass-loading">
          <div class="glass-loading-spinner"></div>
          <span>处理中...</span>
        </div>
      `:this.screenshotData.generatedImageUrl?`
        <div class="glass-screenshot-result">
          <div class="glass-screenshot-generated-label">生成的图片</div>
          <img class="glass-screenshot-generated-img" src="${this.screenshotData.generatedImageUrl}" alt="Generated" />
          <div class="glass-screenshot-result-actions">
            <button class="glass-btn glass-btn-copy-result">复制图片</button>
            <button class="glass-btn glass-btn-save-result">保存图片</button>
          </div>
        </div>
      `:this.screenshotData.result?`
        <div class="glass-screenshot-result">
          <div class="glass-screenshot-result-label">AI 分析结果</div>
          <div class="glass-screenshot-result-text">${this.escapeHtml(this.screenshotData.result)}</div>
          <div class="glass-screenshot-result-actions">
            <button class="glass-btn glass-btn-copy-result">复制结果</button>
          </div>
        </div>
      `:"":""}bindScreenshotViewEvents(){var o;if(!this.shadowRoot)return;const e=this.shadowRoot.querySelector(".glass-search.glass-draggable");e&&e.addEventListener("mousedown",this.handleDragStart);const t=this.shadowRoot.querySelector(".glass-command-tag-close");t==null||t.addEventListener("click",()=>{var r,l;this.screenshotData=null,(l=(r=this.screenshotCallbacks)==null?void 0:r.onClose)==null||l.call(r),this.screenshotCallbacks=null,this.activeCommand=null,this.currentView="commands",this.renderCurrentView(!0,!0)});const s=this.shadowRoot.querySelector(".glass-btn-save");s==null||s.addEventListener("click",()=>{var r,l;(l=(r=this.screenshotCallbacks)==null?void 0:r.onSave)==null||l.call(r)});const i=this.shadowRoot.querySelector(".glass-btn-copy-img");i==null||i.addEventListener("click",()=>{var r,l;(l=(r=this.screenshotCallbacks)==null?void 0:r.onCopy)==null||l.call(r)});const a=this.shadowRoot.querySelector(".glass-btn-ask");a==null||a.addEventListener("click",()=>{var l,h;const r=prompt("请输入你想问的问题：");r&&(this.screenshotData.isLoading=!0,this.renderScreenshotContent(),(h=(l=this.screenshotCallbacks)==null?void 0:l.onAskAI)==null||h.call(l,r))});const n=this.shadowRoot.querySelector(".glass-btn-describe");n==null||n.addEventListener("click",()=>{var r,l;this.screenshotData.isLoading=!0,this.renderScreenshotContent(),(l=(r=this.screenshotCallbacks)==null?void 0:r.onDescribe)==null||l.call(r)}),(o=this.shadowRoot.querySelector(".glass-btn-copy-result"))==null||o.addEventListener("click",()=>{var r;(r=this.screenshotData)!=null&&r.result&&(navigator.clipboard.writeText(this.screenshotData.result),this.showToast("已复制结果"))}),document.removeEventListener("keydown",this.handleScreenshotKeydown),document.addEventListener("keydown",this.handleScreenshotKeydown)}async loadSettingsMenuItems(){try{const e=await K();this.settingsMenuItems=e.globalMenuItems}catch{this.settingsMenuItems=[...H]}}filterCommands(){this.searchQuery?this.filteredItems=this.menuItems.filter(e=>{const t=(e.customLabel||e.label).toLowerCase(),s=e.action.toLowerCase();return t.includes(this.searchQuery)||s.includes(this.searchQuery)}):this.filteredItems=this.sortByRecent(this.menuItems),this.selectedIndex=0,this.renderCommands()}getFilteredRecentTasks(){return this.searchQuery?this.recentSavedTasks.filter(e=>{const t=e.title.toLowerCase(),s=e.content.toLowerCase(),i=e.actionType.toLowerCase(),a=(e.sourceTitle||"").toLowerCase(),n=(e.originalText||"").toLowerCase();return t.includes(this.searchQuery)||s.includes(this.searchQuery)||i.includes(this.searchQuery)||a.includes(this.searchQuery)||n.includes(this.searchQuery)}):this.recentSavedTasks}renderCommands(){if(!this.shadowRoot)return;const e=this.shadowRoot.querySelector(".glass-commands");e&&(this.filteredItems.length===0?e.innerHTML=`
        <div class="glass-empty">
          <span>没有匹配的命令</span>
        </div>
      `:(e.innerHTML=this.filteredItems.map((t,s)=>{const i=s===this.selectedIndex,a=t.customIcon||t.icon,n=t.customLabel||t.label,o=s<9&&!this.searchQuery?s+1:null,r=this.recentCommands.includes(t.id)&&!this.searchQuery;return`
          <div class="glass-item ${i?"selected":""}" data-index="${s}">
            <div class="glass-item-icon">${a}</div>
            <div class="glass-item-label">${this.escapeHtml(n)}</div>
            ${r?'<span class="glass-item-badge">最近</span>':""}
            ${o?`<kbd class="glass-item-key">${o}</kbd>`:""}
          </div>
        `}).join(""),e.querySelectorAll(".glass-item").forEach(t=>{t.addEventListener("click",()=>{this.selectedIndex=parseInt(t.getAttribute("data-index")||"0"),this.executeSelected()}),t.addEventListener("mouseenter",()=>{this.selectedIndex=parseInt(t.getAttribute("data-index")||"0"),this.updateSelection()})})),this.renderMinimizedTasks(),this.renderRecentTasks())}renderMinimizedTasks(){if(!this.shadowRoot)return;const e=this.shadowRoot.querySelector(".glass-minimized-section");if(e){if(this.minimizedTasks.length===0){e.innerHTML="";return}e.innerHTML=`
      <div class="glass-section-label">进行中</div>
      ${this.minimizedTasks.map(t=>{const s=t.iconHtml||this.getDefaultMinimizedIcon(),i=this.getTaskMetaInfo(t);return`
          <div class="glass-minimized-task" data-task-id="${t.id}">
            <div class="glass-task-icon">${s}</div>
            <div class="glass-task-info">
              <div class="glass-task-title">${this.escapeHtml(t.title)}</div>
              <div class="glass-task-meta">${i}</div>
            </div>
            ${t.isLoading?'<div class="glass-minimized-task-loading"></div>':""}
            <button class="glass-minimized-close" data-task-id="${t.id}">&times;</button>
          </div>
        `}).join("")}
    `,e.querySelectorAll(".glass-minimized-task").forEach(t=>{t.addEventListener("click",s=>{if(s.target.classList.contains("glass-minimized-close"))return;const a=t.getAttribute("data-task-id");a&&this.restoreMinimizedTask(a)})}),e.querySelectorAll(".glass-minimized-close").forEach(t=>{t.addEventListener("click",s=>{s.stopPropagation();const i=t.getAttribute("data-task-id");i&&this.dismissMinimizedTask(i)})})}}renderRecentTasks(){if(!this.shadowRoot)return;const e=this.shadowRoot.querySelector(".glass-recent-section");if(!e)return;const t=this.getFilteredRecentTasks();if(t.length===0){e.innerHTML="";return}e.innerHTML=`
      <div class="glass-section-label">最近记录</div>
      ${t.map(s=>{const i=this.getActionIcon(s.actionType),a=this.getSavedTaskMetaInfo(s);return`
          <div class="glass-recent-task" data-task-id="${s.id}">
            <div class="glass-task-icon">${i}</div>
            <div class="glass-task-info">
              <div class="glass-task-title">${this.escapeHtml(s.title)}</div>
              <div class="glass-task-meta">${a}</div>
            </div>
            <button class="glass-recent-close" data-task-id="${s.id}">&times;</button>
          </div>
        `}).join("")}
    `,e.querySelectorAll(".glass-recent-task").forEach(s=>{s.addEventListener("click",i=>{if(i.target.classList.contains("glass-recent-close"))return;const n=s.getAttribute("data-task-id");if(n){const o=this.recentSavedTasks.find(r=>r.id===n);o&&this.restoreSavedTask(o)}})}),e.querySelectorAll(".glass-recent-close").forEach(s=>{s.addEventListener("click",i=>{i.stopPropagation();const a=s.getAttribute("data-task-id");a&&this.deleteSavedTask(a)})})}getActionIcon(e){return{translate:u.translate,summarize:u.summarize,summarizePage:u.summarizePage,explain:u.explain,rewrite:u.rewrite,codeExplain:u.codeExplain}[e]||u.messageCircle}getSavedTaskMetaInfo(e){const t=[],s=this.formatTimeAgo(e.savedAt);if(t.push(s),e.actionType==="summarizePage"){if(e.sourceTitle)t.push(e.sourceTitle);else if(e.sourceUrl)try{t.push(new URL(e.sourceUrl).hostname)}catch{}}else if(e.resultType==="translate"){if(e.sourceUrl)try{t.push(new URL(e.sourceUrl).hostname)}catch{}if(e.originalText){const i=e.originalText.slice(0,30)+(e.originalText.length>30?"...":"");t.push(`"${i}"`)}}return t.join(" · ")}getTaskMetaInfo(e){const t=[],s=this.formatTimeAgo(e.createdAt);if(t.push(s),e.actionType==="summarizePage"){if(e.sourceTitle)t.push(e.sourceTitle);else if(e.sourceUrl)try{t.push(new URL(e.sourceUrl).hostname)}catch{}}else if(e.resultType==="translate"){if(e.sourceUrl)try{t.push(new URL(e.sourceUrl).hostname)}catch{}if(e.originalText){const i=e.originalText.slice(0,30)+(e.originalText.length>30?"...":"");t.push(`"${i}"`)}}return e.isLoading&&t.push("处理中"),t.join(" · ")}formatTimeAgo(e){const s=Date.now()-e,i=Math.floor(s/1e3),a=Math.floor(i/60),n=Math.floor(a/60);return i<60?"刚刚":a<60?`${a}分钟前`:n<24?`${n}小时前`:new Date(e).toLocaleDateString()}async loadRecentSavedTasks(){var e;try{const t=((e=this.config.history)==null?void 0:e.panelDisplayCount)||y.panelDisplayCount;this.recentSavedTasks=await ie(t),this.shadowRoot&&this.currentView==="commands"&&this.renderRecentTasks()}catch(t){console.error("Failed to load recent saved tasks:",t),this.recentSavedTasks=[]}}async deleteSavedTask(e){try{await ne(e),this.recentSavedTasks=this.recentSavedTasks.filter(t=>t.id!==e),this.renderRecentTasks()}catch(t){console.error("Failed to delete saved task:",t)}}restoreSavedTask(e){const t={translate:"翻译",summarize:"总结",summarizePage:"总结页面",explain:"解释",rewrite:"改写",codeExplain:"代码解释"};if(this.activeCommand={id:`saved_${e.id}`,icon:this.getActionIcon(e.actionType),label:t[e.actionType]||e.title,action:e.actionType,enabled:!0,order:0},this.aiResultData={title:e.title,content:e.content,originalText:e.originalText,isLoading:!1,resultType:e.resultType,translateTargetLanguage:e.translateTargetLanguage,actionType:e.actionType,sourceUrl:e.sourceUrl,sourceTitle:e.sourceTitle,createdAt:e.createdAt},e.actionType==="translate"&&e.originalText){const s=e.originalText;this.aiResultCallbacks={onStop:()=>V(),onTranslateLanguageChange:async i=>{await this.retranslate(s,i)}}}else this.aiResultCallbacks={};this.currentView="commands",this.renderCurrentView(!1,!0)}async retranslate(e,t){if(!this.aiResultData)return;const s=this.config.useStreaming?(a,n)=>{this.streamUpdate(a,n)}:void 0,i=me(t);try{const a=await O(e,i,this.config,s);a.success&&a.result?this.updateAIResult(a.result):this.updateAIResult(a.error||"翻译失败")}catch(a){this.updateAIResult(`错误: ${a}`)}}updateSelection(){if(!this.shadowRoot)return;this.shadowRoot.querySelectorAll(".glass-item").forEach((t,s)=>{s===this.selectedIndex?(t.classList.add("selected"),t.scrollIntoView({block:"nearest"})):t.classList.remove("selected")})}selectNext(){this.filteredItems.length!==0&&(this.selectedIndex=(this.selectedIndex+1)%this.filteredItems.length,this.updateSelection())}selectPrev(){this.filteredItems.length!==0&&(this.selectedIndex=(this.selectedIndex-1+this.filteredItems.length)%this.filteredItems.length,this.updateSelection())}async executeSelected(){var s,i,a,n;if(this.filteredItems.length===0){const o=(s=this.shadowRoot)==null?void 0:s.querySelector(".glass-input"),r=(i=o==null?void 0:o.value)==null?void 0:i.trim();r&&this.startQuickAsk(r);return}const e=this.filteredItems[this.selectedIndex];if(!e)return;if(await this.saveRecentCommand(e.id),e.action==="settings"){await this.loadSettingsMenuItems(),this.tempConfig=JSON.parse(JSON.stringify(this.config)),this.settingsChanged=!1,this.currentView="settings",this.viewStack=[],this.renderCurrentView(!0,!0);return}if(["translate","summarize","explain","rewrite","codeExplain","summarizePage"].includes(e.action)){(a=this.callbacks)==null||a.onSelect(e);return}if(e.action==="browseTrail"){this.showBrowseTrail();return}if(e.action==="contextChat"){this.showContextChat();return}this.hide(),(n=this.callbacks)==null||n.onSelect(e)}async showBrowseTrail(){this.browseTrailSessions=await re(),this.browseTrailSearch="",this.browseTrailDisplayCount=50,this.activeCommand={id:"browseTrail",action:"browseTrail",label:"浏览轨迹",icon:u.history,enabled:!0,order:0},this.currentView="browseTrail",this.viewStack=[],this.renderCurrentView(!0,!0)}getBrowseTrailViewHTML(){return`
      <div class="glass-search glass-draggable">
        <div class="glass-command-tag" data-action="browseTrail">
          <span class="glass-command-tag-icon">${u.history}</span>
          <span class="glass-command-tag-label">浏览轨迹</span>
          <button class="glass-command-tag-close">&times;</button>
        </div>
        <input
          type="text"
          class="glass-input"
          placeholder="搜索历史记录..."
          autocomplete="off"
          spellcheck="false"
        />
        <kbd class="glass-kbd">ESC</kbd>
      </div>
      <div class="glass-divider"></div>
      <div class="glass-body">
        <div class="glass-trail-content">
          ${this.getBrowseTrailContentHTML()}
        </div>
      </div>
      <div class="glass-footer">
        <div class="glass-trail-footer-actions">
          <button class="glass-btn glass-btn-trail-clear">清空历史</button>
          <button class="glass-btn glass-btn-trail-export">导出</button>
        </div>
        <div class="glass-brand">
          <span class="glass-logo">${u.logo}</span>
        </div>
      </div>
    `}getBrowseTrailContentHTML(){const e=[];for(const l of this.browseTrailSessions)e.push(...l.entries);e.sort((l,h)=>h.visitedAt-l.visitedAt);const t=this.browseTrailSearch.toLowerCase(),s=t?e.filter(l=>{var h;return l.title.toLowerCase().includes(t)||l.url.toLowerCase().includes(t)||((h=l.summary)==null?void 0:h.toLowerCase().includes(t))}):e;if(s.length===0)return`
        <div class="glass-trail-empty">
          <div class="glass-trail-empty-icon">${u.history}</div>
          <div class="glass-trail-empty-text">
            ${t?"没有找到匹配的记录":"还没有浏览记录"}
          </div>
          <div class="glass-trail-empty-hint">
            ${t?"试试其他关键词":"浏览网页时会自动记录"}
          </div>
        </div>
      `;const i=s.slice(0,this.browseTrailDisplayCount),a=s.length>this.browseTrailDisplayCount,n=this.groupTrailByDate(i),o=Object.entries(n).map(([l,h])=>`
      <div class="glass-trail-group">
        <div class="glass-trail-date">${l}</div>
        <div class="glass-trail-entries">
          ${h.map(g=>{const p=new Date(g.visitedAt).toLocaleTimeString("zh-CN",{hour:"2-digit",minute:"2-digit"});let m="";try{m=new URL(g.url).hostname}catch{}return`
              <div class="glass-trail-entry" data-url="${this.escapeHtml(g.url)}">
                <div class="glass-trail-entry-info">
                  <div class="glass-trail-entry-title">${this.escapeHtml(g.title||"无标题")}</div>
                  <div class="glass-trail-entry-meta">
                    <span class="glass-trail-entry-domain">${this.escapeHtml(m)}</span>
                    <span class="glass-trail-entry-time">${p}</span>
                  </div>
                </div>
                <button class="glass-trail-entry-delete" data-id="${g.id}" title="删除">&times;</button>
              </div>
            `}).join("")}
        </div>
      </div>
    `).join(""),r=a?`
      <div class="glass-trail-load-more">
        <button class="glass-btn glass-btn-load-more">
          加载更多 (${s.length-this.browseTrailDisplayCount} 条)
        </button>
      </div>
    `:"";return o+r}groupTrailByDate(e){const t={},s=new Date().toDateString(),i=new Date(Date.now()-864e5).toDateString();for(const a of e){const n=new Date(a.visitedAt).toDateString();let o;n===s?o="今天":n===i?o="昨天":o=new Date(a.visitedAt).toLocaleDateString("zh-CN",{month:"long",day:"numeric",weekday:"short"}),t[o]||(t[o]=[]),t[o].push(a)}return t}bindBrowseTrailEvents(){if(!this.shadowRoot)return;const e=this.shadowRoot.querySelector(".glass-input"),t=this.shadowRoot.querySelector(".glass-search.glass-draggable");t&&t.addEventListener("mousedown",this.handleDragStart);const s=this.shadowRoot.querySelector(".glass-command-tag-close");s==null||s.addEventListener("click",n=>{n.stopPropagation(),this.activeCommand=null,this.currentView="commands",this.viewStack=[],this.renderCurrentView(!0,!0)}),e==null||e.addEventListener("input",()=>{var o;this.browseTrailSearch=e.value.trim(),this.browseTrailDisplayCount=50;const n=(o=this.shadowRoot)==null?void 0:o.querySelector(".glass-trail-content");n&&(n.innerHTML=this.getBrowseTrailContentHTML(),this.bindTrailEntryEvents())}),e==null||e.addEventListener("keydown",n=>{n.key==="Escape"&&(n.preventDefault(),this.activeCommand=null,this.currentView="commands",this.viewStack=[],this.renderCurrentView(!0,!0))});const i=this.shadowRoot.querySelector(".glass-btn-trail-clear");i==null||i.addEventListener("click",async()=>{var n;if(confirm("确定要清空所有浏览记录吗？")){await le(),this.browseTrailSessions=[];const o=(n=this.shadowRoot)==null?void 0:n.querySelector(".glass-trail-content");o&&(o.innerHTML=this.getBrowseTrailContentHTML())}});const a=this.shadowRoot.querySelector(".glass-btn-trail-export");a==null||a.addEventListener("click",()=>{Le(this.browseTrailSessions),this.showToast("已导出浏览历史")}),this.bindTrailEntryEvents()}bindTrailEntryEvents(){if(!this.shadowRoot)return;this.shadowRoot.querySelectorAll(".glass-trail-entry").forEach(t=>{t.addEventListener("click",s=>{if(s.target.closest(".glass-trail-entry-delete"))return;const a=t.getAttribute("data-url");a&&window.open(a,"_blank")})}),this.shadowRoot.querySelectorAll(".glass-trail-entry-delete").forEach(t=>{t.addEventListener("click",async s=>{var a;s.stopPropagation();const i=t.getAttribute("data-id");if(i){this.browseTrailSessions=await Ce(i);const n=(a=this.shadowRoot)==null?void 0:a.querySelector(".glass-trail-content");n&&(n.innerHTML=this.getBrowseTrailContentHTML(),this.bindTrailEntryEvents())}})});const e=this.shadowRoot.querySelector(".glass-btn-load-more");e==null||e.addEventListener("click",()=>{var s;this.browseTrailDisplayCount+=50;const t=(s=this.shadowRoot)==null?void 0:s.querySelector(".glass-trail-content");t&&(t.innerHTML=this.getBrowseTrailContentHTML(),this.bindTrailEntryEvents())})}async startQuickAsk(e){const t=window.location.href;this.chatSession=ge(t,document.title),this.isChatStreaming=!1,this.isQuickAsk=!0,this.activeCommand={id:"quickAsk",action:"contextChat",label:"快速提问",icon:u.messageCircle,enabled:!0,order:0},this.currentView="contextChat",this.viewStack=[],this.searchQuery="",this.renderCurrentView(!0,!0),requestAnimationFrame(()=>{var i;const s=(i=this.shadowRoot)==null?void 0:i.querySelector(".glass-chat-input");s&&(s.value=e,this.sendChatMessage(s))})}async showContextChat(){const e=window.location.href,t=await Me(e);t?this.chatSession=t:this.chatSession=ge(e,document.title),this.isChatStreaming=!1,this.isQuickAsk=!1,this.activeCommand={id:"contextChat",action:"contextChat",label:"上下文追问",icon:u.messageCircle,enabled:!0,order:0},this.currentView="contextChat",this.viewStack=[],this.renderCurrentView(!0,!0)}getContextChatViewHTML(){var t;const e=((t=this.activeCommand)==null?void 0:t.label)||"上下文追问";return`
      <div class="glass-search glass-draggable">
        <div class="glass-command-tag" data-action="contextChat">
          <span class="glass-command-tag-icon">${u.messageCircle}</span>
          <span class="glass-command-tag-label">${this.escapeHtml(e)}</span>
          <button class="glass-command-tag-close">&times;</button>
        </div>
        <input
          type="text"
          class="glass-input glass-chat-input"
          placeholder="输入问题后按回车..."
          autocomplete="off"
          spellcheck="false"
          ${this.isChatStreaming?"disabled":""}
        />
        <kbd class="glass-kbd">ESC</kbd>
      </div>
      <div class="glass-divider"></div>
      <div class="glass-body">
        <div class="glass-chat-content">
          ${this.getContextChatContentHTML()}
        </div>
      </div>
      <div class="glass-footer">
        <div class="glass-chat-footer-actions">
          <button class="glass-btn glass-btn-chat-clear">清空对话</button>
        </div>
        <div class="glass-brand">
          <span class="glass-logo">${u.logo}</span>
        </div>
      </div>
    `}getContextChatContentHTML(){if(!this.chatSession||this.chatSession.messages.length===0){const e=this.isQuickAsk?"直接输入问题，AI 将为你解答":"开始提问，AI 将基于当前页面内容回答";return`
        <div class="glass-chat-empty">
          <div class="glass-chat-empty-icon">${u.messageCircle}</div>
          <div class="glass-chat-empty-text">${e}</div>
        </div>
      `}return this.chatSession.messages.map(e=>{const t=e.role==="user"?"你":"AI",s=e.role==="user"?"glass-chat-msg-user":"glass-chat-msg-assistant";let i="";return e.references&&e.references.length>0&&(i=`<div class="glass-chat-references">${e.references.map(n=>`<div class="glass-chat-reference">"${this.escapeHtml(n.text)}"</div>`).join("")}</div>`),i+=`<div class="glass-chat-msg-text">${this.formatAIContent(e.content)}</div>`,`
        <div class="glass-chat-msg ${s}">
          <div class="glass-chat-msg-label">${t}</div>
          ${i}
        </div>
      `}).join("")}bindContextChatEvents(){if(!this.shadowRoot)return;const e=this.shadowRoot.querySelector(".glass-chat-input"),t=this.shadowRoot.querySelector(".glass-search.glass-draggable");t&&t.addEventListener("mousedown",this.handleDragStart);const s=this.shadowRoot.querySelector(".glass-command-tag-close");s==null||s.addEventListener("click",a=>{a.stopPropagation(),this.activeCommand=null,this.chatSession=null,this.currentView="commands",this.viewStack=[],this.renderCurrentView(!0,!0)}),e==null||e.addEventListener("keydown",a=>{a.isComposing||(a.key==="Enter"&&!a.shiftKey?(a.preventDefault(),this.isChatStreaming||this.sendChatMessage(e)):a.key==="Escape"&&(a.preventDefault(),this.activeCommand=null,this.chatSession=null,this.currentView="commands",this.viewStack=[],this.renderCurrentView(!0,!0)))});const i=this.shadowRoot.querySelector(".glass-btn-chat-clear");i==null||i.addEventListener("click",async()=>{var a;if(this.chatSession){this.chatSession.messages=[],this.isQuickAsk||await he(this.chatSession);const n=(a=this.shadowRoot)==null?void 0:a.querySelector(".glass-chat-content");n&&(n.innerHTML=this.getContextChatContentHTML())}}),this.scrollChatToBottom()}async sendChatMessage(e){var h,g;if(!this.chatSession||this.isChatStreaming)return;const t=e.value.trim();if(!t)return;const{cleanContent:s,references:i}=ze(t),a=ue("user",s,i.length>0?i:void 0);this.chatSession.messages.push(a),e.value="",e.disabled=!0,e.placeholder="AI 正在回复...";const n=(h=this.shadowRoot)==null?void 0:h.querySelector(".glass-chat-content");n&&(n.innerHTML=this.getContextChatContentHTML()),this.scrollChatToBottom();const o=ue("assistant","");if(this.chatSession.messages.push(o),n){n.innerHTML=this.getContextChatContentHTML()+`
        <div class="glass-chat-msg glass-chat-msg-assistant glass-chat-streaming">
          <div class="glass-chat-msg-label">AI</div>
          <div class="glass-chat-msg-text">${this.getLoadingHTML()}</div>
        </div>
      `;const p=n.querySelector(".glass-chat-msg:nth-last-child(2)");p&&((g=p.querySelector(".glass-chat-msg-text"))==null?void 0:g.textContent)===""&&p.remove()}this.scrollChatToBottom(),this.isChatStreaming=!0;const r=this.isQuickAsk?"你是一个有帮助的AI助手。请简洁、准确地回答用户的问题。":De(this.chatSession),l=Ee(this.chatSession.messages.slice(0,-1));try{const p=(b,T)=>{var k;if(!this.chatSession)return;const S=this.chatSession.messages[this.chatSession.messages.length-1];S.role==="assistant"&&(S.content=T);const w=(k=this.shadowRoot)==null?void 0:k.querySelector(".glass-chat-streaming .glass-chat-msg-text");w&&(w.innerHTML=this.formatAIContent(T)),this.scrollChatToBottom()},m=await O(l,r,this.config,p);if(m.success&&m.result){const b=this.chatSession.messages[this.chatSession.messages.length-1];b.role==="assistant"&&(b.content=m.result)}else{const b=this.chatSession.messages[this.chatSession.messages.length-1];b.role==="assistant"&&(b.content=m.error||"AI 请求失败")}this.isQuickAsk||await he(this.chatSession)}catch(p){const m=this.chatSession.messages[this.chatSession.messages.length-1];m.role==="assistant"&&(m.content=`错误: ${p}`)}finally{this.isChatStreaming=!1}n&&(n.innerHTML=this.getContextChatContentHTML()),this.scrollChatToBottom(),e.disabled=!1,e.placeholder="输入问题后按回车...",e.focus()}scrollChatToBottom(){if(!this.shadowRoot)return;const e=this.shadowRoot.querySelector(".glass-body");e&&(e.scrollTop=e.scrollHeight)}escapeHtml(e){const t=document.createElement("div");return t.textContent=e,t.innerHTML}getStyles(){return`
      * {
        box-sizing: border-box;
        margin: 0;
        padding: 0;
      }

      /* Transparent overlay to capture clicks outside panel */
      .glass-overlay {
        position: fixed;
        inset: 0;
        z-index: 2147483646;
      }

      /* ========================================
         Apple Liquid Glass Design System
         Authentic iOS 26 / visionOS aesthetics
         ======================================== */

      :host {
        /* Dark mode - Primary palette */
        --glass-bg: rgba(28, 28, 30, 0.72);
        --glass-bg-elevated: rgba(44, 44, 46, 0.65);
        --glass-bg-hover: rgba(255, 255, 255, 0.08);
        --glass-bg-selected: rgba(255, 255, 255, 0.12);
        --glass-border: rgba(255, 255, 255, 0.08);
        --glass-border-strong: rgba(255, 255, 255, 0.15);
        --glass-divider: rgba(255, 255, 255, 0.06);

        /* Text hierarchy */
        --text-primary: rgba(255, 255, 255, 0.92);
        --text-secondary: rgba(255, 255, 255, 0.55);
        --text-tertiary: rgba(255, 255, 255, 0.35);

        /* Shadows - subtle depth */
        --shadow-panel:
          0 0 0 0.5px rgba(255, 255, 255, 0.1),
          0 24px 80px -12px rgba(0, 0, 0, 0.5),
          0 12px 40px -8px rgba(0, 0, 0, 0.3);
        --shadow-item: 0 1px 3px rgba(0, 0, 0, 0.12);

        /* Blur values */
        --blur-panel: 40px;
        --blur-overlay: 8px;

        /* Timing */
        --duration-fast: 150ms;
        --duration-normal: 250ms;
        --ease-out: cubic-bezier(0.25, 0.46, 0.45, 0.94);
        --ease-spring: cubic-bezier(0.34, 1.56, 0.64, 1);
      }

      /* Light mode overrides */
      .light {
        --glass-bg: rgba(255, 255, 255, 0.72);
        --glass-bg-elevated: rgba(255, 255, 255, 0.85);
        --glass-bg-hover: rgba(0, 0, 0, 0.04);
        --glass-bg-selected: rgba(0, 0, 0, 0.08);
        --glass-border: rgba(0, 0, 0, 0.06);
        --glass-border-strong: rgba(0, 0, 0, 0.12);
        --glass-divider: rgba(0, 0, 0, 0.05);

        --text-primary: rgba(0, 0, 0, 0.88);
        --text-secondary: rgba(0, 0, 0, 0.50);
        --text-tertiary: rgba(0, 0, 0, 0.30);

        --shadow-panel:
          0 0 0 0.5px rgba(0, 0, 0, 0.08),
          0 24px 80px -12px rgba(0, 0, 0, 0.18),
          0 12px 40px -8px rgba(0, 0, 0, 0.1);
      }

      /* ========================================
         Main Panel - Liquid Glass container
         ======================================== */
      .glass-panel {
        /* Reset inherited styles to prevent page style pollution */
        text-align: left;
        line-height: normal;
        letter-spacing: normal;
        word-spacing: normal;
        text-transform: none;
        text-indent: 0;
        text-shadow: none;
        direction: ltr;
        white-space: normal;
        cursor: default;
        visibility: visible;

        position: fixed;
        top: 18%;
        left: 50%;
        transform: translateX(-50%);
        width: 520px;
        max-width: calc(100vw - 40px);
        max-height: 65vh;

        background: var(--glass-bg);
        backdrop-filter: blur(var(--blur-panel)) saturate(180%);
        -webkit-backdrop-filter: blur(var(--blur-panel)) saturate(180%);

        border: 0.5px solid var(--glass-border-strong);
        border-radius: 18px;
        box-shadow: var(--shadow-panel);

        display: flex;
        flex-direction: column;
        overflow: hidden;
        z-index: 2147483647;

        font-family: -apple-system, BlinkMacSystemFont, "SF Pro Display", "SF Pro Text", system-ui, sans-serif;
        font-feature-settings: "kern" 1, "liga" 1;
        -webkit-font-smoothing: antialiased;
      }

      .glass-panel.glass-panel-enter {
        animation: panelIn var(--duration-normal) var(--ease-spring);
      }

      .glass-panel.glass-panel-enter-restored {
        animation: panelInRestored var(--duration-normal) var(--ease-spring);
      }

      @keyframes panelIn {
        from {
          opacity: 0;
          transform: translateX(-50%) translateY(-16px) scale(0.97);
        }
        to {
          opacity: 1;
          transform: translateX(-50%) translateY(0) scale(1);
        }
      }

      @keyframes panelInRestored {
        from {
          opacity: 0;
          transform: translateY(-16px) scale(0.97);
        }
        to {
          opacity: 1;
          transform: none;
        }
      }

      .glass-panel-exit {
        animation: panelOut var(--duration-fast) var(--ease-out) forwards;
      }

      @keyframes panelOut {
        from {
          opacity: 1;
          transform: translateX(-50%) translateY(0) scale(1);
        }
        to {
          opacity: 0;
          transform: translateX(-50%) translateY(-8px) scale(0.98);
        }
      }

      .glass-panel-exit-dragged {
        animation: panelOutDragged var(--duration-fast) var(--ease-out) forwards;
      }

      @keyframes panelOutDragged {
        from {
          opacity: 1;
          transform: scale(1);
        }
        to {
          opacity: 0;
          transform: translateY(-8px) scale(0.98);
        }
      }

      /* ========================================
         Search Bar
         ======================================== */
      .glass-search {
        display: flex;
        align-items: center;
        gap: 12px;
        padding: 14px 16px;
      }

      .glass-search.glass-draggable {
        cursor: move;
        user-select: none;
      }

      .glass-search-icon {
        color: var(--text-tertiary);
        flex-shrink: 0;
        display: flex;
        align-items: center;
        justify-content: center;
        height: 26px;
        width: 18px;
      }

      .glass-search-icon svg {
        width: 18px;
        height: 18px;
      }

      /* Command Tag (active command indicator) */
      .glass-command-tag {
        display: flex;
        align-items: center;
        gap: 6px;
        height: 26px;
        padding: 0 8px 0 6px;
        background: var(--glass-bg-selected);
        border: 0.5px solid var(--glass-border-strong);
        border-radius: 8px;
        flex-shrink: 0;
        cursor: default;
        box-sizing: border-box;
      }

      .glass-command-tag-icon {
        display: flex;
        align-items: center;
        justify-content: center;
        color: var(--text-primary);
      }

      .glass-command-tag-icon svg {
        width: 14px;
        height: 14px;
      }

      .glass-command-tag-label {
        font-size: 13px;
        font-weight: 500;
        color: var(--text-primary);
        white-space: nowrap;
      }

      .glass-command-tag-close {
        display: flex;
        align-items: center;
        justify-content: center;
        width: 16px;
        height: 16px;
        border: none;
        background: transparent;
        color: var(--text-tertiary);
        cursor: pointer;
        border-radius: 4px;
        font-size: 14px;
        line-height: 1;
        margin-left: 2px;
        transition: all var(--duration-fast) var(--ease-out);
      }

      .glass-command-tag-close:hover {
        color: var(--text-primary);
      }

      .glass-input {
        flex: 1;
        background: transparent;
        border: none;
        outline: none;
        font-size: 16px;
        font-weight: 400;
        letter-spacing: -0.01em;
        color: var(--text-primary);
        font-family: inherit;
      }

      .glass-input:disabled {
        cursor: default;
      }

      .glass-input::placeholder {
        color: var(--text-tertiary);
      }

      .glass-kbd {
        font-size: 11px;
        font-weight: 500;
        letter-spacing: 0.02em;
        color: var(--text-tertiary);
        background: var(--glass-bg-hover);
        border: 0.5px solid var(--glass-border);
        height: 26px;
        padding: 0 7px;
        border-radius: 5px;
        font-family: "SF Mono", ui-monospace, monospace;
        display: flex;
        align-items: center;
        justify-content: center;
        box-sizing: border-box;
      }

      /* ========================================
         AI Content Area (unified interface)
         ======================================== */
      .glass-ai-content-area {
        padding: 16px;
        min-height: 100px;
      }

      .glass-ai-content-area .glass-ai-content {
        font-size: 14px;
        line-height: 1.6;
        color: var(--text-primary);
      }

      .glass-ai-content-area .glass-ai-content code {
        background: var(--glass-bg-hover);
        padding: 2px 6px;
        border-radius: 4px;
        font-family: "SF Mono", ui-monospace, monospace;
        font-size: 13px;
      }

      /* Footer action buttons */
      .glass-ai-footer-actions {
        display: flex;
        align-items: center;
        gap: 6px;
      }

      .glass-footer-btn {
        display: flex;
        align-items: center;
        justify-content: center;
        width: 32px;
        height: 32px;
        padding: 0;
        border: 0.5px solid var(--glass-border);
        background: var(--glass-bg-hover);
        border-radius: 8px;
        color: var(--text-secondary);
        cursor: pointer;
        transition: all var(--duration-fast) var(--ease-out);
      }

      .glass-footer-btn:hover {
        background: var(--glass-bg-selected);
        color: var(--text-primary);
      }

      .glass-footer-btn svg {
        width: 16px;
        height: 16px;
      }

      .glass-footer-btn.glass-btn-stop {
        color: #ff6b6b;
        border-color: rgba(255, 107, 107, 0.3);
      }

      .glass-footer-btn.glass-btn-stop:hover {
        background: rgba(255, 107, 107, 0.15);
        color: #ff5252;
      }

      .glass-footer-btn.copied,
      .glass-footer-btn.saved {
        color: #4ade80;
        border-color: rgba(74, 222, 128, 0.3);
      }

      /* ========================================
         Divider
         ======================================== */
      .glass-divider {
        height: 0.5px;
        background: var(--glass-divider);
        margin: 0 16px;
      }

      /* ========================================
         Commands List
         ======================================== */
      .glass-body {
        flex: 1;
        overflow-y: auto;
        overscroll-behavior: contain;
      }

      .glass-commands {
        padding: 8px;
      }

      .glass-item {
        display: flex;
        align-items: center;
        gap: 12px;
        padding: 10px 12px;
        border-radius: 10px;
        cursor: pointer;
        transition:
          background var(--duration-fast) var(--ease-out),
          transform var(--duration-fast) var(--ease-out);
      }

      .glass-item:hover {
        background: var(--glass-bg-hover);
      }

      .glass-item.selected {
        background: var(--glass-bg-selected);
      }

      .glass-item:active {
        transform: scale(0.98);
      }

      .glass-item-icon {
        width: 32px;
        height: 32px;
        display: flex;
        align-items: center;
        justify-content: center;
        background: var(--glass-bg-elevated);
        border: 0.5px solid var(--glass-border);
        border-radius: 8px;
        color: var(--text-primary);
        flex-shrink: 0;
        transition: all var(--duration-fast) var(--ease-out);
      }

      .glass-item.selected .glass-item-icon {
        background: var(--text-primary);
        border-color: transparent;
        color: var(--glass-bg);
      }

      .glass-item-icon svg {
        width: 16px;
        height: 16px;
      }

      .glass-item-label {
        flex: 1;
        font-size: 14px;
        font-weight: 450;
        letter-spacing: -0.01em;
        color: var(--text-primary);
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
      }

      .glass-item-badge {
        font-size: 10px;
        font-weight: 500;
        letter-spacing: 0.02em;
        text-transform: uppercase;
        color: var(--text-tertiary);
        background: var(--glass-bg-hover);
        padding: 2px 6px;
        border-radius: 4px;
      }

      .glass-item-key {
        font-size: 11px;
        font-weight: 500;
        color: var(--text-tertiary);
        background: var(--glass-bg-hover);
        border: 0.5px solid var(--glass-border);
        padding: 2px 6px;
        border-radius: 5px;
        font-family: "SF Mono", ui-monospace, monospace;
        min-width: 20px;
        text-align: center;
      }

      /* ========================================
         Empty State
         ======================================== */
      .glass-empty {
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 40px 20px;
        color: var(--text-tertiary);
        font-size: 14px;
      }

      /* ========================================
         Footer
         ======================================== */
      .glass-footer {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 10px 16px;
        border-top: 0.5px solid var(--glass-divider);
      }

      .glass-hints {
        display: flex;
        gap: 14px;
        font-size: 12px;
        color: var(--text-tertiary);
      }

      .glass-hints span {
        display: flex;
        align-items: center;
        gap: 4px;
      }

      .glass-hints kbd {
        font-size: 10px;
        font-weight: 500;
        color: var(--text-tertiary);
        background: var(--glass-bg-hover);
        border: 0.5px solid var(--glass-border);
        padding: 2px 5px;
        border-radius: 4px;
        font-family: "SF Mono", ui-monospace, monospace;
      }

      .glass-brand {
        display: flex;
        align-items: center;
      }

      .glass-logo {
        width: 16px;
        height: 16px;
        color: var(--text-tertiary);
        opacity: 0.6;
      }

      .glass-logo svg {
        width: 100%;
        height: 100%;
      }

      /* ========================================
         Scrollbar - Minimal & Isolated
         ======================================== */
      .glass-body,
      .glass-ai-content,
      .glass-ai-result-body {
        /* Firefox */
        scrollbar-width: thin;
        scrollbar-color: var(--glass-border) transparent;
      }

      .glass-body::-webkit-scrollbar,
      .glass-ai-content::-webkit-scrollbar,
      .glass-ai-result-body::-webkit-scrollbar {
        width: 6px !important;
        height: 6px !important;
        background: transparent !important;
      }

      .glass-body::-webkit-scrollbar-track,
      .glass-ai-content::-webkit-scrollbar-track,
      .glass-ai-result-body::-webkit-scrollbar-track {
        background: transparent !important;
        border-radius: 3px;
      }

      .glass-body::-webkit-scrollbar-thumb,
      .glass-ai-content::-webkit-scrollbar-thumb,
      .glass-ai-result-body::-webkit-scrollbar-thumb {
        background: var(--glass-border) !important;
        border-radius: 3px;
        border: none !important;
      }

      .glass-body::-webkit-scrollbar-thumb:hover,
      .glass-ai-content::-webkit-scrollbar-thumb:hover,
      .glass-ai-result-body::-webkit-scrollbar-thumb:hover {
        background: var(--glass-border-strong) !important;
      }

      .glass-body::-webkit-scrollbar-corner,
      .glass-ai-content::-webkit-scrollbar-corner,
      .glass-ai-result-body::-webkit-scrollbar-corner {
        background: transparent !important;
      }

      /* ========================================
         Responsive
         ======================================== */
      @media (max-width: 580px) {
        .glass-panel {
          top: 12%;
          width: calc(100vw - 24px);
          max-height: 75vh;
          border-radius: 14px;
        }

        .glass-hints {
          display: none;
        }

        .glass-item-key {
          display: none;
        }

        .glass-item-badge {
          display: none;
        }
      }

      /* ========================================
         Reduced Motion
         ======================================== */
      @media (prefers-reduced-motion: reduce) {
        .glass-panel,
        .glass-item,
        .glass-item-icon {
          animation: none;
          transition: none;
        }
      }

      /* ========================================
         Header with Back Button
         ======================================== */
      .glass-header {
        display: flex;
        align-items: center;
        gap: 12px;
        padding: 14px 16px;
      }

      .glass-header.glass-draggable {
        cursor: move;
        user-select: none;
      }

      .glass-header.glass-draggable:active {
        cursor: grabbing;
      }

      .glass-back-btn {
        display: flex;
        align-items: center;
        justify-content: center;
        width: 28px;
        height: 28px;
        border: none;
        background: var(--glass-bg-hover);
        border-radius: 8px;
        color: var(--text-primary);
        cursor: pointer;
        transition: all var(--duration-fast) var(--ease-out);
      }

      .glass-back-btn:hover {
        background: var(--glass-bg-selected);
      }

      .glass-header-title {
        flex: 1;
        font-size: 16px;
        font-weight: 600;
        color: var(--text-primary);
      }

      .glass-header-actions {
        display: flex;
        align-items: center;
        gap: 6px;
      }

      .glass-header-btn {
        display: flex;
        align-items: center;
        justify-content: center;
        width: 28px;
        height: 28px;
        border: none;
        background: var(--glass-bg-hover);
        border-radius: 8px;
        color: var(--text-secondary);
        cursor: pointer;
        transition: all var(--duration-fast) var(--ease-out);
      }

      .glass-header-btn:hover {
        background: var(--glass-bg-selected);
        color: var(--text-primary);
      }

      .glass-header-btn.active {
        background: var(--glass-bg-selected);
        color: var(--text-primary);
      }

      .glass-header-btn svg {
        width: 16px;
        height: 16px;
      }

      .glass-header-btn.glass-btn-stop {
        color: #ff6b6b;
      }

      .glass-header-btn.glass-btn-stop:hover {
        background: rgba(255, 107, 107, 0.15);
        color: #ff5252;
      }

      .glass-header-btn.copied {
        color: #4ade80;
      }

      .glass-minimize-btn {
        display: flex;
        align-items: center;
        justify-content: center;
        width: 28px;
        height: 28px;
        border: none;
        background: var(--glass-bg-hover);
        border-radius: 8px;
        color: var(--text-secondary);
        cursor: pointer;
        transition: all var(--duration-fast) var(--ease-out);
      }

      .glass-minimize-btn:hover {
        background: var(--glass-bg-selected);
        color: var(--text-primary);
      }

      /* ========================================
         Dragging State
         ======================================== */
      .glass-panel-dragging {
        transition: none !important;
        user-select: none;
      }

      /* ========================================
         Minimized Icon
         ======================================== */
      .glass-minimized-icon {
        position: fixed;
        bottom: 24px;
        right: 24px;
        width: 48px;
        height: 48px;
        border-radius: 50%;
        background: var(--glass-bg);
        backdrop-filter: blur(var(--blur-panel)) saturate(180%);
        -webkit-backdrop-filter: blur(var(--blur-panel)) saturate(180%);
        border: 0.5px solid var(--glass-border-strong);
        box-shadow: var(--shadow-panel);
        cursor: pointer;
        z-index: 2147483647;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: all var(--duration-fast) var(--ease-out);
        animation: minimizedIn var(--duration-normal) var(--ease-spring);
      }

      @keyframes minimizedIn {
        from {
          opacity: 0;
          transform: scale(0.5);
        }
        to {
          opacity: 1;
          transform: scale(1);
        }
      }

      .glass-minimized-icon:hover {
        transform: scale(1.08);
        box-shadow:
          0 0 0 0.5px rgba(255, 255, 255, 0.15),
          0 12px 40px -8px rgba(0, 0, 0, 0.4);
      }

      .glass-minimized-icon:hover .glass-minimized-tooltip {
        opacity: 1;
        transform: translateX(-50%) translateY(0);
        pointer-events: auto;
      }

      .glass-minimized-icon-inner {
        position: relative;
        display: flex;
        align-items: center;
        justify-content: center;
        color: var(--text-primary);
      }

      .glass-minimized-icon-inner svg {
        width: 20px;
        height: 20px;
      }

      .glass-minimized-loading {
        position: absolute;
        inset: -4px;
        border: 2px solid transparent;
        border-top-color: var(--text-primary);
        border-radius: 50%;
        animation: spin 0.8s linear infinite;
      }

      .glass-minimized-tooltip {
        position: absolute;
        bottom: calc(100% + 8px);
        left: 50%;
        transform: translateX(-50%) translateY(4px);
        padding: 6px 12px;
        background: var(--glass-bg-elevated);
        border: 0.5px solid var(--glass-border);
        border-radius: 8px;
        font-size: 12px;
        font-weight: 500;
        color: var(--text-primary);
        white-space: nowrap;
        opacity: 0;
        pointer-events: none;
        transition: all var(--duration-fast) var(--ease-out);
        box-shadow: var(--shadow-item);
      }

      /* ========================================
         Minimized Tasks Section (in Commands View)
         ======================================== */
      .glass-minimized-section:empty {
        display: none;
      }

      .glass-minimized-section {
        border-top: 0.5px solid var(--glass-divider);
        padding: 8px 0;
      }

      .glass-section-label {
        padding: 4px 16px 8px;
        font-size: 11px;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        color: var(--text-tertiary);
      }

      .glass-minimized-task {
        display: flex;
        align-items: center;
        gap: 12px;
        padding: 10px 12px;
        cursor: pointer;
        border-radius: 10px;
        margin: 0 8px 4px;
        transition: background var(--duration-fast) var(--ease-out);
      }

      .glass-minimized-task:hover {
        background: var(--glass-bg-hover);
      }

      .glass-task-icon {
        width: 36px;
        height: 36px;
        display: flex;
        align-items: center;
        justify-content: center;
        background: var(--glass-bg-elevated);
        border: 0.5px solid var(--glass-border);
        border-radius: 10px;
        color: var(--text-primary);
        flex-shrink: 0;
      }

      .glass-task-icon svg {
        width: 18px;
        height: 18px;
      }

      .glass-task-info {
        flex: 1;
        min-width: 0;
        display: flex;
        flex-direction: column;
        gap: 2px;
      }

      .glass-task-title {
        font-size: 14px;
        font-weight: 500;
        letter-spacing: -0.01em;
        color: var(--text-primary);
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
      }

      .glass-task-meta {
        font-size: 12px;
        color: var(--text-tertiary);
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
      }

      .glass-minimized-task-loading {
        width: 14px;
        height: 14px;
        border: 1.5px solid var(--glass-border);
        border-top-color: var(--text-primary);
        border-radius: 50%;
        animation: spin 0.8s linear infinite;
        flex-shrink: 0;
      }

      .glass-minimized-close {
        width: 20px;
        height: 20px;
        border: none;
        background: transparent;
        color: var(--text-tertiary);
        cursor: pointer;
        border-radius: 4px;
        display: flex;
        align-items: center;
        justify-content: center;
        flex-shrink: 0;
        font-size: 16px;
        line-height: 1;
        transition: all var(--duration-fast) var(--ease-out);
      }

      .glass-minimized-close:hover {
        color: #ff6b6b;
      }

      /* ========================================
         Recent Tasks Section (Saved Tasks from IndexedDB)
         ======================================== */
      .glass-recent-section:empty {
        display: none;
      }

      .glass-recent-section {
        border-top: 0.5px solid var(--glass-divider);
        padding: 8px 0;
      }

      .glass-recent-task {
        display: flex;
        align-items: center;
        gap: 12px;
        padding: 10px 12px;
        cursor: pointer;
        border-radius: 10px;
        margin: 0 8px 4px;
        transition: background var(--duration-fast) var(--ease-out);
      }

      .glass-recent-task:hover {
        background: var(--glass-bg-hover);
      }

      .glass-recent-close {
        width: 20px;
        height: 20px;
        border: none;
        background: transparent;
        color: var(--text-tertiary);
        cursor: pointer;
        border-radius: 4px;
        display: flex;
        align-items: center;
        justify-content: center;
        flex-shrink: 0;
        font-size: 16px;
        line-height: 1;
        transition: all var(--duration-fast) var(--ease-out);
      }

      .glass-recent-close:hover {
        color: #ff6b6b;
      }

      /* ========================================
         AI Result View
         ======================================== */
      .glass-source-info {
        display: flex;
        align-items: center;
        gap: 8px;
        padding: 8px 16px;
        background: var(--glass-bg-hover);
        border-bottom: 0.5px solid var(--glass-divider);
      }

      .glass-source-icon {
        color: var(--text-tertiary);
        flex-shrink: 0;
        display: flex;
        align-items: center;
      }

      .glass-source-content {
        flex: 1;
        min-width: 0;
        display: flex;
        align-items: center;
        gap: 8px;
        font-size: 12px;
      }

      .glass-source-link {
        color: var(--text-secondary);
        text-decoration: none;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
        transition: color var(--duration-fast) var(--ease-out);
      }

      .glass-source-link:hover {
        color: var(--text-primary);
        text-decoration: underline;
      }

      .glass-source-title {
        color: var(--text-secondary);
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
      }

      .glass-source-meta {
        color: var(--text-tertiary);
        white-space: nowrap;
        flex-shrink: 0;
      }

      .glass-source-meta::before {
        content: '·';
        margin-right: 8px;
      }

      .glass-ai-result-body {
        padding: 16px;
      }

      .glass-ai-content {
        font-size: 14px;
        line-height: 1.6;
        color: var(--text-primary);
      }

      .glass-ai-content code {
        background: var(--glass-bg-hover);
        padding: 2px 6px;
        border-radius: 4px;
        font-family: "SF Mono", ui-monospace, monospace;
        font-size: 13px;
      }

      .glass-loading {
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 12px;
        padding: 40px 20px;
        color: var(--text-secondary);
      }

      .glass-spinner {
        width: 24px;
        height: 24px;
        border: 2px solid var(--glass-border);
        border-top-color: var(--text-primary);
        border-radius: 50%;
        animation: spin 0.8s linear infinite;
      }

      @keyframes spin {
        to { transform: rotate(360deg); }
      }

      .glass-ai-footer {
        padding: 12px 16px;
        border-top: 0.5px solid var(--glass-divider);
      }

      .glass-ai-actions {
        display: flex;
        justify-content: flex-end;
        gap: 8px;
      }

      .glass-btn {
        display: flex;
        align-items: center;
        gap: 6px;
        padding: 8px 14px;
        border: 0.5px solid var(--glass-border);
        background: var(--glass-bg-hover);
        border-radius: 8px;
        color: var(--text-primary);
        font-size: 13px;
        font-weight: 500;
        cursor: pointer;
        transition: all var(--duration-fast) var(--ease-out);
        white-space: nowrap;
      }

      .glass-btn:hover {
        background: var(--glass-bg-selected);
        border-color: var(--glass-border-strong);
      }

      .glass-btn.active {
        background: rgba(59, 130, 246, 0.2);
        border-color: rgba(59, 130, 246, 0.5);
      }

      .glass-btn.copied {
        background: rgba(34, 197, 94, 0.2);
        border-color: rgba(34, 197, 94, 0.5);
      }

      .glass-btn svg {
        width: 14px;
        height: 14px;
      }

      .glass-btn-stop {
        background: rgba(239, 68, 68, 0.1);
        border-color: rgba(239, 68, 68, 0.3);
      }

      .glass-btn-stop:hover {
        background: rgba(239, 68, 68, 0.2);
      }

      /* Compare View */
      .glass-compare-view {
        display: flex;
        gap: 16px;
      }

      .glass-compare-item {
        flex: 1;
        min-width: 0;
      }

      .glass-compare-label {
        font-size: 11px;
        font-weight: 500;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        color: var(--text-tertiary);
        margin-bottom: 8px;
      }

      .glass-compare-content {
        font-size: 14px;
        line-height: 1.6;
        color: var(--text-primary);
      }

      .glass-compare-divider {
        width: 1px;
        background: var(--glass-divider);
      }

      .glass-panel-wide {
        width: 680px;
        max-width: calc(100vw - 40px);
      }

      /* Language Select */
      .glass-lang-select {
        appearance: none;
        height: 32px;
        padding: 0 28px 0 10px;
        border: 0.5px solid var(--glass-border);
        background: var(--glass-bg-hover);
        background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 24 24' fill='none' stroke='%239CA3AF' stroke-width='2'%3E%3Cpolyline points='6 9 12 15 18 9'/%3E%3C/svg%3E");
        background-repeat: no-repeat;
        background-position: right 8px center;
        border-radius: 8px;
        color: var(--text-primary);
        font-size: 13px;
        cursor: pointer;
        transition: all var(--duration-fast) var(--ease-out);
      }

      .glass-lang-select:hover {
        background-color: var(--glass-bg-selected);
        border-color: var(--glass-border-strong);
      }

      /* ========================================
         Settings Views
         ======================================== */
      .glass-settings-flat {
        padding: 0;
      }

      .glass-settings-section {
        padding: 16px;
        border-bottom: 1px solid var(--glass-divider);
      }

      .glass-settings-section:last-child {
        border-bottom: none;
      }

      .glass-settings-section-title {
        font-size: 12px;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        color: var(--text-secondary);
        margin-bottom: 16px;
      }

      .glass-settings-body {
        max-height: 400px;
        overflow-y: auto;
        scrollbar-width: thin;
        scrollbar-color: var(--glass-border) transparent;
      }

      .glass-settings-body::-webkit-scrollbar {
        width: 6px !important;
        height: 6px !important;
        background: transparent !important;
      }

      .glass-settings-body::-webkit-scrollbar-track {
        background: transparent !important;
        border-radius: 3px;
      }

      .glass-settings-body::-webkit-scrollbar-thumb {
        background: var(--glass-border) !important;
        border-radius: 3px;
        border: none !important;
      }

      .glass-settings-body::-webkit-scrollbar-thumb:hover {
        background: var(--glass-border-strong) !important;
      }

      .glass-settings-body::-webkit-scrollbar-corner {
        background: transparent !important;
      }

      .glass-settings-list {
        padding: 8px;
      }

      .glass-settings-item {
        display: flex;
        align-items: center;
        gap: 12px;
        padding: 12px;
        border-radius: 10px;
        cursor: pointer;
        transition: background var(--duration-fast) var(--ease-out);
      }

      .glass-settings-item:hover {
        background: var(--glass-bg-hover);
      }

      .glass-settings-icon {
        width: 32px;
        height: 32px;
        display: flex;
        align-items: center;
        justify-content: center;
        background: var(--glass-bg-elevated);
        border: 0.5px solid var(--glass-border);
        border-radius: 8px;
        color: var(--text-primary);
        flex-shrink: 0;
      }

      .glass-settings-icon svg {
        width: 18px;
        height: 18px;
      }

      .glass-settings-label {
        flex: 1;
        font-size: 14px;
        font-weight: 450;
        color: var(--text-primary);
      }

      .glass-settings-arrow {
        color: var(--text-tertiary);
        display: flex;
        align-items: center;
        justify-content: center;
      }

      .glass-settings-arrow svg {
        width: 14px;
        height: 14px;
      }

      /* Form Elements */
      .glass-form {
        padding: 16px;
        display: flex;
        flex-direction: column;
        gap: 16px;
      }

      .glass-form-group {
        display: flex;
        flex-direction: column;
        gap: 6px;
      }

      .glass-form-group + .glass-form-group {
        margin-top: 12px;
      }

      .glass-form-group.glass-form-toggle {
        flex-direction: row;
        align-items: center;
        justify-content: space-between;
        padding: 6px 0;
      }

      .glass-form-label {
        font-size: 14px;
        font-weight: 500;
        color: var(--text-primary);
      }

      .glass-form-hint {
        font-size: 12px;
        color: var(--text-tertiary);
        line-height: 1.4;
        margin-top: -2px;
      }

      .glass-select {
        appearance: none;
        width: 100%;
        padding: 10px 36px 10px 12px;
        border: 1px solid var(--glass-border);
        background: var(--glass-bg-hover);
        background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 24 24' fill='none' stroke='%239CA3AF' stroke-width='2'%3E%3Cpolyline points='6 9 12 15 18 9'/%3E%3C/svg%3E");
        background-repeat: no-repeat;
        background-position: right 12px center;
        border-radius: 8px;
        color: var(--text-primary);
        font-size: 14px;
        cursor: pointer;
        transition: all var(--duration-fast) var(--ease-out);
        box-sizing: border-box;
      }

      .glass-select:hover {
        background-color: var(--glass-bg-selected);
        border-color: var(--glass-border-strong);
      }

      .glass-select:focus {
        outline: none;
        border-color: rgba(59, 130, 246, 0.5);
      }

      .glass-input-field {
        width: 100%;
        padding: 10px 12px;
        border: 1px solid var(--glass-border);
        background: var(--glass-bg-hover);
        border-radius: 8px;
        color: var(--text-primary);
        font-size: 14px;
        outline: none;
        transition: all var(--duration-fast) var(--ease-out);
        box-sizing: border-box;
      }

      .glass-input-field:focus {
        border-color: rgba(59, 130, 246, 0.5);
        background: rgba(59, 130, 246, 0.1);
      }

      .glass-input-field::placeholder {
        color: var(--text-tertiary);
      }

      /* Toggle Switch */
      .glass-toggle {
        position: relative;
        display: inline-block;
        width: 44px;
        height: 24px;
      }

      .glass-toggle input {
        opacity: 0;
        width: 0;
        height: 0;
      }

      .glass-toggle-slider {
        position: absolute;
        cursor: pointer;
        inset: 0;
        background: var(--glass-bg-hover);
        border: 0.5px solid var(--glass-border);
        border-radius: 24px;
        transition: all var(--duration-fast) var(--ease-out);
      }

      .glass-toggle-slider::before {
        content: "";
        position: absolute;
        height: 18px;
        width: 18px;
        left: 2px;
        bottom: 2px;
        background: var(--text-primary);
        border-radius: 50%;
        transition: all var(--duration-fast) var(--ease-out);
      }

      .glass-toggle input:checked + .glass-toggle-slider {
        background: rgba(59, 130, 246, 0.8);
        border-color: rgba(59, 130, 246, 0.8);
      }

      .glass-toggle input:checked + .glass-toggle-slider::before {
        transform: translateX(20px);
        background: white;
      }

      .glass-toggle-small {
        width: 36px;
        height: 20px;
      }

      .glass-toggle-small .glass-toggle-slider::before {
        height: 14px;
        width: 14px;
      }

      .glass-toggle-small input:checked + .glass-toggle-slider::before {
        transform: translateX(16px);
      }

      /* Menu Management */
      .glass-menu-list {
        padding: 8px;
        display: flex;
        flex-direction: column;
        gap: 4px;
      }

      .glass-menu-item {
        display: flex;
        align-items: center;
        gap: 10px;
        padding: 10px 12px;
        background: var(--glass-bg-hover);
        border: 0.5px solid var(--glass-border);
        border-radius: 10px;
        transition: all var(--duration-fast) var(--ease-out);
      }

      .glass-menu-item:hover {
        background: var(--glass-bg-selected);
      }

      .glass-menu-item.dragging {
        opacity: 0.5;
      }

      .glass-menu-item.drag-over {
        border-color: rgba(59, 130, 246, 0.5);
        background: rgba(59, 130, 246, 0.1);
      }

      .glass-menu-drag {
        color: var(--text-tertiary);
        cursor: grab;
        font-size: 12px;
        letter-spacing: 2px;
      }

      .glass-menu-icon {
        width: 24px;
        height: 24px;
        display: flex;
        align-items: center;
        justify-content: center;
        color: var(--text-primary);
      }

      .glass-menu-icon svg {
        width: 16px;
        height: 16px;
      }

      .glass-menu-label {
        flex: 1;
        font-size: 14px;
        color: var(--text-primary);
      }

      .glass-menu-btn {
        display: flex;
        align-items: center;
        justify-content: center;
        width: 28px;
        height: 28px;
        border: none;
        background: transparent;
        border-radius: 6px;
        color: var(--text-tertiary);
        cursor: pointer;
        transition: all var(--duration-fast) var(--ease-out);
      }

      .glass-menu-btn:hover {
        background: var(--glass-bg-hover);
        color: var(--text-primary);
      }

      .glass-menu-delete:hover {
        background: rgba(239, 68, 68, 0.1);
        color: rgb(239, 68, 68);
      }

      /* Footer */
      .glass-footer-hint {
        font-size: 12px;
        color: var(--text-tertiary);
      }

      .glass-btn-danger {
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 6px;
        padding: 10px 16px;
        background: rgba(239, 68, 68, 0.1);
        border: 1px solid rgba(239, 68, 68, 0.3);
        border-radius: 8px;
        color: rgb(239, 68, 68);
        font-size: 14px;
        font-weight: 500;
        cursor: pointer;
        transition: all var(--duration-fast) var(--ease-out);
        width: 100%;
      }

      .glass-btn-danger:hover {
        background: rgba(239, 68, 68, 0.2);
        border-color: rgba(239, 68, 68, 0.5);
      }

      .glass-btn-reset {
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 6px;
        padding: 10px 16px;
        background: var(--glass-bg-hover);
        border: 1px solid var(--glass-border);
        border-radius: 8px;
        color: var(--text-secondary);
        font-size: 14px;
        font-weight: 500;
        cursor: pointer;
        transition: all var(--duration-fast) var(--ease-out);
        width: 100%;
      }

      .glass-btn-reset:hover {
        background: var(--glass-bg-selected);
        border-color: var(--glass-border-strong);
        color: var(--text-primary);
      }

      .glass-settings-footer {
        justify-content: flex-end;
      }

      .glass-settings-footer-actions {
        display: flex;
        gap: 8px;
      }

      .glass-btn-cancel {
        padding: 6px 16px;
        background: var(--glass-bg-hover);
        border: 1px solid var(--glass-border);
        border-radius: 8px;
        color: var(--text-secondary);
        font-size: 13px;
        cursor: pointer;
        transition: all var(--duration-fast) var(--ease-out);
      }

      .glass-btn-cancel:hover {
        background: var(--glass-bg-selected);
        color: var(--text-primary);
      }

      .glass-btn-primary {
        padding: 6px 16px;
        background: var(--text-primary);
        border: 1px solid transparent;
        border-radius: 8px;
        color: var(--glass-bg);
        font-size: 13px;
        font-weight: 500;
        cursor: pointer;
        transition: all var(--duration-fast) var(--ease-out);
      }

      .glass-btn-primary:hover {
        opacity: 0.85;
      }

      .glass-btn-add {
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 6px;
        padding: 10px 16px;
        background: rgba(59, 130, 246, 0.1);
        border: 1px solid rgba(59, 130, 246, 0.3);
        border-radius: 8px;
        color: rgb(59, 130, 246);
        font-size: 14px;
        font-weight: 500;
        cursor: pointer;
        transition: all var(--duration-fast) var(--ease-out);
        width: 100%;
      }

      .glass-btn-add:hover {
        background: rgba(59, 130, 246, 0.2);
        border-color: rgba(59, 130, 246, 0.5);
      }

      /* Screenshot View */
      .glass-screenshot-body {
        display: flex;
        flex-direction: column;
        gap: 12px;
        max-height: 400px;
        overflow-y: auto;
      }

      .glass-screenshot-preview {
        padding: 12px;
        display: flex;
        justify-content: center;
        background: var(--glass-bg-hover);
        border-radius: 8px;
      }

      .glass-screenshot-preview img {
        max-width: 100%;
        max-height: 200px;
        border-radius: 6px;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
      }

      .glass-screenshot-content {
        padding: 0 12px 12px;
      }

      .glass-screenshot-actions {
        display: flex;
        align-items: center;
        gap: 6px;
      }

      .glass-screenshot-actions .glass-btn {
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 4px;
        padding: 6px 10px;
        font-size: 12px;
      }

      .glass-screenshot-result {
        display: flex;
        flex-direction: column;
        gap: 8px;
      }

      .glass-screenshot-result-label,
      .glass-screenshot-generated-label {
        font-size: 12px;
        font-weight: 600;
        color: var(--text-secondary);
        text-transform: uppercase;
        letter-spacing: 0.5px;
      }

      .glass-screenshot-result-text {
        font-size: 14px;
        line-height: 1.6;
        color: var(--text-primary);
        white-space: pre-wrap;
        max-height: 150px;
        overflow-y: auto;
        padding: 12px;
        background: var(--glass-bg-hover);
        border-radius: 8px;
      }

      .glass-screenshot-generated-img {
        max-width: 100%;
        border-radius: 8px;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
      }

      .glass-screenshot-result-actions {
        display: flex;
        justify-content: flex-end;
        gap: 8px;
        margin-top: 8px;
      }

      .glass-loading {
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 10px;
        padding: 20px;
        color: var(--text-secondary);
      }

      .glass-loading-spinner {
        width: 20px;
        height: 20px;
        border: 2px solid var(--glass-border);
        border-top-color: var(--text-primary);
        border-radius: 50%;
        animation: glass-spin 0.8s linear infinite;
      }

      @keyframes glass-spin {
        to { transform: rotate(360deg); }
      }

      /* Toast */
      .glass-toast {
        position: fixed;
        bottom: 20px;
        left: 50%;
        transform: translateX(-50%) translateY(20px);
        padding: 10px 20px;
        background: var(--glass-bg);
        border: 0.5px solid var(--glass-border-strong);
        border-radius: 20px;
        color: var(--text-primary);
        font-size: 13px;
        opacity: 0;
        transition: all var(--duration-fast) var(--ease-out);
        z-index: 10;
      }

      .glass-toast.show {
        opacity: 1;
        transform: translateX(-50%) translateY(0);
      }

      /* View Transition */
      .glass-view-transition {
        animation: viewTransition var(--duration-fast) var(--ease-out);
      }

      @keyframes viewTransition {
        from {
          opacity: 0.8;
        }
        to {
          opacity: 1;
        }
      }

      /* ========================================
         Browse Trail View
         ======================================== */
      .glass-trail-content {
        padding: 8px;
      }

      .glass-trail-empty {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        padding: 40px 20px;
        text-align: center;
      }

      .glass-trail-empty-icon {
        width: 48px;
        height: 48px;
        display: flex;
        align-items: center;
        justify-content: center;
        color: var(--text-tertiary);
        margin-bottom: 12px;
      }

      .glass-trail-empty-icon svg {
        width: 32px;
        height: 32px;
      }

      .glass-trail-empty-text {
        font-size: 14px;
        font-weight: 500;
        color: var(--text-secondary);
        margin-bottom: 4px;
      }

      .glass-trail-empty-hint {
        font-size: 12px;
        color: var(--text-tertiary);
      }

      .glass-trail-group {
        margin-bottom: 12px;
      }

      .glass-trail-date {
        font-size: 12px;
        font-weight: 600;
        color: var(--text-secondary);
        padding: 4px 12px;
        margin-bottom: 4px;
      }

      .glass-trail-entries {
        display: flex;
        flex-direction: column;
        gap: 2px;
      }

      .glass-trail-entry {
        display: flex;
        align-items: center;
        padding: 10px 12px;
        border-radius: 10px;
        cursor: pointer;
        transition: background var(--duration-fast) var(--ease-out);
      }

      .glass-trail-entry:hover {
        background: var(--glass-bg-hover);
      }

      .glass-trail-entry-info {
        flex: 1;
        min-width: 0;
      }

      .glass-trail-entry-title {
        font-size: 14px;
        font-weight: 500;
        color: var(--text-primary);
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
        margin-bottom: 2px;
      }

      .glass-trail-entry-meta {
        display: flex;
        gap: 8px;
        font-size: 12px;
        color: var(--text-tertiary);
      }

      .glass-trail-entry-domain {
        max-width: 150px;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }

      .glass-trail-entry-delete {
        display: flex;
        align-items: center;
        justify-content: center;
        width: 24px;
        height: 24px;
        border: none;
        background: transparent;
        color: var(--text-tertiary);
        cursor: pointer;
        border-radius: 6px;
        font-size: 16px;
        opacity: 0;
        transition: all var(--duration-fast) var(--ease-out);
        margin-left: 8px;
        flex-shrink: 0;
      }

      .glass-trail-entry:hover .glass-trail-entry-delete {
        opacity: 1;
      }

      .glass-trail-entry-delete:hover {
        color: #ff6b6b;
      }

      .glass-trail-load-more {
        display: flex;
        justify-content: center;
        padding: 12px 0;
      }

      .glass-btn-load-more {
        background: var(--glass-bg-hover);
        border: 0.5px solid var(--glass-border);
        color: var(--text-secondary);
        padding: 6px 16px;
        border-radius: 8px;
        font-size: 12px;
        cursor: pointer;
        transition: all var(--duration-fast) var(--ease-out);
      }

      .glass-btn-load-more:hover {
        background: var(--glass-border);
        color: var(--text-primary);
      }

      .glass-trail-footer-actions {
        display: flex;
        gap: 8px;
      }

      /* ========================================
         Context Chat View
         ======================================== */
      .glass-chat-content {
        padding: 16px;
        display: flex;
        flex-direction: column;
        gap: 16px;
      }

      .glass-chat-empty {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        padding: 40px 20px;
        text-align: center;
      }

      .glass-chat-empty-icon {
        width: 48px;
        height: 48px;
        display: flex;
        align-items: center;
        justify-content: center;
        color: var(--text-tertiary);
        margin-bottom: 12px;
      }

      .glass-chat-empty-icon svg {
        width: 32px;
        height: 32px;
      }

      .glass-chat-empty-text {
        font-size: 14px;
        color: var(--text-secondary);
      }

      .glass-chat-msg {
        display: flex;
        flex-direction: column;
        gap: 4px;
      }

      .glass-chat-msg-label {
        font-size: 11px;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        color: var(--text-tertiary);
      }

      .glass-chat-msg-text {
        font-size: 14px;
        line-height: 1.6;
        color: var(--text-primary);
      }

      .glass-chat-msg-text code {
        background: var(--glass-bg-hover);
        padding: 2px 6px;
        border-radius: 4px;
        font-family: "SF Mono", ui-monospace, monospace;
        font-size: 13px;
      }

      .glass-chat-msg-user .glass-chat-msg-text {
        background: var(--glass-bg-selected);
        padding: 10px 14px;
        border-radius: 12px;
        border-top-left-radius: 4px;
      }

      .glass-chat-msg-assistant .glass-chat-msg-text {
        background: var(--glass-bg-hover);
        padding: 10px 14px;
        border-radius: 12px;
        border-top-left-radius: 4px;
      }

      .glass-chat-references {
        display: flex;
        flex-direction: column;
        gap: 4px;
        margin-bottom: 8px;
      }

      .glass-chat-reference {
        font-size: 12px;
        color: var(--text-secondary);
        background: var(--glass-bg-hover);
        padding: 6px 10px;
        border-radius: 6px;
        border-left: 3px solid var(--glass-border-strong);
        font-style: italic;
      }

      .glass-chat-streaming .glass-chat-msg-text {
        box-shadow: inset 0 0 0 1px var(--glass-border-strong);
      }

      .glass-chat-footer-actions {
        display: flex;
        gap: 8px;
      }
    `}}const Ne=`
.thecircle-screenshot-overlay {
  position: fixed;
  inset: 0;
  z-index: 2147483646;
  background: transparent;
  cursor: crosshair;
  animation: thecircle-ss-fade-in 0.15s ease-out;
}
.thecircle-screenshot-overlay.thecircle-screenshot-selecting {
  background: transparent;
}
.thecircle-screenshot-overlay.thecircle-screenshot-idle {
  background: rgba(0, 0, 0, 0.3);
}
.thecircle-screenshot-overlay.thecircle-screenshot-has-selection {
  cursor: default;
}
.thecircle-screenshot-fade-out {
  animation: thecircle-ss-fade-out 0.2s ease-out forwards;
}
@keyframes thecircle-ss-fade-in {
  from { opacity: 0; }
  to { opacity: 1; }
}
@keyframes thecircle-ss-fade-out {
  from { opacity: 1; }
  to { opacity: 0; }
}
.thecircle-screenshot-hint {
  position: fixed;
  top: 20px;
  left: 50%;
  transform: translateX(-50%);
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 12px 20px;
  background: rgba(30, 30, 30, 0.9);
  backdrop-filter: blur(20px);
  -webkit-backdrop-filter: blur(20px);
  border: 1px solid rgba(255, 255, 255, 0.15);
  border-radius: 9999px;
  color: rgba(255, 255, 255, 0.95);
  font-size: 14px;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2);
  transition: opacity 0.2s ease;
}
.thecircle-screenshot-hint-divider {
  color: rgba(255, 255, 255, 0.3);
}
.thecircle-screenshot-hint-key {
  background: rgba(255, 255, 255, 0.15);
  padding: 2px 8px;
  border-radius: 4px;
  font-size: 12px;
  font-weight: 500;
}
.thecircle-screenshot-selection {
  position: fixed;
  border: 2px solid #3b82f6;
  background: transparent;
  box-shadow: 0 0 0 9999px rgba(0, 0, 0, 0.5);
  pointer-events: none;
  cursor: move;
}
.thecircle-screenshot-selection.thecircle-screenshot-selection-active {
  pointer-events: auto;
  cursor: move;
}
.thecircle-screenshot-selection.thecircle-screenshot-selection-breathe {
  animation: thecircle-ss-breathe 0.4s ease-out;
}
@keyframes thecircle-ss-breathe {
  0% { border-color: #3b82f6; box-shadow: 0 0 0 9999px rgba(0, 0, 0, 0.5); }
  50% { border-color: #60a5fa; box-shadow: 0 0 0 9999px rgba(0, 0, 0, 0.4), 0 0 20px rgba(59, 130, 246, 0.5); }
  100% { border-color: #3b82f6; box-shadow: 0 0 0 9999px rgba(0, 0, 0, 0.5); }
}
.thecircle-screenshot-size {
  position: fixed;
  transform: translateX(-50%);
  padding: 4px 10px;
  background: rgba(30, 30, 30, 0.9);
  border: 1px solid rgba(255, 255, 255, 0.15);
  border-radius: 4px;
  color: rgba(255, 255, 255, 0.95);
  font-size: 12px;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  pointer-events: none;
}
.thecircle-screenshot-toolbar {
  position: fixed;
  transform: translateX(-50%);
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 6px;
  background: rgba(30, 30, 30, 0.85);
  backdrop-filter: blur(30px) saturate(180%);
  -webkit-backdrop-filter: blur(30px) saturate(180%);
  border: 0.5px solid rgba(255, 255, 255, 0.15);
  border-radius: 12px;
  box-shadow: 0 8px 32px rgba(0, 0, 0, 0.25), inset 0 0.5px 0 rgba(255, 255, 255, 0.15);
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  animation: thecircle-ss-fade-in 0.15s ease-out;
  z-index: 2147483647;
}
.thecircle-screenshot-toolbar-btn {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 32px;
  height: 32px;
  padding: 0;
  background: rgba(255, 255, 255, 0.1);
  border: 0.5px solid rgba(255, 255, 255, 0.15);
  border-radius: 8px;
  color: rgba(255, 255, 255, 0.95);
  cursor: pointer;
  transition: all 0.15s ease;
}
.thecircle-screenshot-toolbar-btn svg {
  width: 16px;
  height: 16px;
}
.thecircle-screenshot-toolbar-btn:hover {
  background: rgba(255, 255, 255, 0.2);
  border-color: rgba(255, 255, 255, 0.3);
}
.thecircle-screenshot-toolbar-btn-primary {
  background: rgba(59, 130, 246, 0.25);
  border-color: rgba(59, 130, 246, 0.4);
  color: #60a5fa;
}
.thecircle-screenshot-toolbar-btn-primary:hover {
  background: rgba(59, 130, 246, 0.35);
  border-color: rgba(59, 130, 246, 0.6);
}
@media (prefers-color-scheme: light) {
  .thecircle-screenshot-toolbar {
    background: rgba(255, 255, 255, 0.85);
    border-color: rgba(0, 0, 0, 0.1);
    box-shadow: 0 8px 32px rgba(0, 0, 0, 0.15), inset 0 0.5px 0 rgba(255, 255, 255, 0.8);
  }
  .thecircle-screenshot-toolbar-btn {
    background: rgba(0, 0, 0, 0.05);
    border-color: rgba(0, 0, 0, 0.1);
    color: rgba(0, 0, 0, 0.85);
  }
  .thecircle-screenshot-toolbar-btn:hover {
    background: rgba(0, 0, 0, 0.1);
    border-color: rgba(0, 0, 0, 0.2);
  }
  .thecircle-screenshot-toolbar-btn-primary {
    background: rgba(59, 130, 246, 0.15);
    border-color: rgba(59, 130, 246, 0.3);
    color: #2563eb;
  }
  .thecircle-screenshot-toolbar-btn-primary:hover {
    background: rgba(59, 130, 246, 0.25);
    border-color: rgba(59, 130, 246, 0.5);
  }
}
`;let fe=!1;function Oe(){if(fe)return;const c=document.getElementById("thecircle-screenshot-styles");c&&c.remove();const e=document.createElement("style");e.id="thecircle-screenshot-styles",e.textContent=Ne,document.head.appendChild(e),fe=!0}class Fe{constructor(){d(this,"overlay",null);d(this,"selectionBox",null);d(this,"sizeIndicator",null);d(this,"hintText",null);d(this,"toolbar",null);d(this,"isSelecting",!1);d(this,"isDragging",!1);d(this,"hasSelection",!1);d(this,"startX",0);d(this,"startY",0);d(this,"dragOffsetX",0);d(this,"dragOffsetY",0);d(this,"currentArea",null);d(this,"callbacks",null);Oe(),this.handleMouseDown=this.handleMouseDown.bind(this),this.handleMouseMove=this.handleMouseMove.bind(this),this.handleMouseUp=this.handleMouseUp.bind(this),this.handleKeyDown=this.handleKeyDown.bind(this)}show(e){this.callbacks=e,this.createOverlay(),this.attachEventListeners()}hide(){this.detachEventListeners(),this.overlay&&(this.overlay.classList.add("thecircle-screenshot-fade-out"),setTimeout(()=>{var e;(e=this.overlay)==null||e.remove(),this.overlay=null,this.selectionBox=null,this.sizeIndicator=null,this.hintText=null,this.toolbar=null},200))}hideImmediately(){this.detachEventListeners(),this.overlay&&(this.overlay.remove(),this.overlay=null,this.selectionBox=null,this.sizeIndicator=null,this.hintText=null,this.toolbar=null)}createOverlay(){this.overlay=document.createElement("div"),this.overlay.className="thecircle-screenshot-overlay thecircle-screenshot-idle",this.hintText=document.createElement("div"),this.hintText.className="thecircle-screenshot-hint",this.hintText.innerHTML=`
      <span>拖拽选择截图区域</span>
      <span class="thecircle-screenshot-hint-divider">|</span>
      <span class="thecircle-screenshot-hint-key">ESC</span>
      <span>取消</span>
      <span class="thecircle-screenshot-hint-divider">|</span>
      <span>点击截取全屏</span>
    `,this.overlay.appendChild(this.hintText),this.selectionBox=document.createElement("div"),this.selectionBox.className="thecircle-screenshot-selection",this.selectionBox.style.display="none",this.overlay.appendChild(this.selectionBox),this.sizeIndicator=document.createElement("div"),this.sizeIndicator.className="thecircle-screenshot-size",this.sizeIndicator.style.display="none",this.overlay.appendChild(this.sizeIndicator),document.body.appendChild(this.overlay)}createToolbar(){var s;if(!this.overlay||!this.currentArea)return;(s=this.toolbar)==null||s.remove(),this.toolbar=document.createElement("div"),this.toolbar.className="thecircle-screenshot-toolbar";const e=this.currentArea.y+this.currentArea.height+10,t=this.currentArea.x+this.currentArea.width/2;this.toolbar.style.left=`${t}px`,this.toolbar.style.top=`${e}px`,e+50>window.innerHeight&&(this.toolbar.style.top=`${this.currentArea.y-50}px`),this.toolbar.innerHTML=`
      <button class="thecircle-screenshot-toolbar-btn thecircle-screenshot-toolbar-btn-primary" data-action="confirm" title="确认">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <polyline points="20 6 9 17 4 12"></polyline>
        </svg>
      </button>
      <button class="thecircle-screenshot-toolbar-btn" data-action="reselect" title="重选">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <path d="M1 4v6h6"></path>
          <path d="M3.51 15a9 9 0 1 0 2.13-9.36L1 10"></path>
        </svg>
      </button>
      <button class="thecircle-screenshot-toolbar-btn" data-action="cancel" title="取消">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <line x1="18" y1="6" x2="6" y2="18"></line>
          <line x1="6" y1="6" x2="18" y2="18"></line>
        </svg>
      </button>
    `,this.toolbar.addEventListener("click",i=>{var r;const n=i.target.closest("button");if(!n)return;const o=n.dataset.action;o==="confirm"?this.confirmSelection():o==="reselect"?this.resetSelection():o==="cancel"&&(this.hide(),(r=this.callbacks)==null||r.onCancel())}),this.overlay.appendChild(this.toolbar)}confirmSelection(){const e=this.currentArea;this.hideImmediately(),requestAnimationFrame(()=>{var t;(t=this.callbacks)==null||t.onSelect(e)})}resetSelection(){var e;this.hasSelection=!1,this.currentArea=null,this.isDragging=!1,(e=this.toolbar)==null||e.remove(),this.toolbar=null,this.overlay&&(this.overlay.classList.add("thecircle-screenshot-idle"),this.overlay.classList.remove("thecircle-screenshot-has-selection")),this.selectionBox&&(this.selectionBox.style.display="none",this.selectionBox.classList.remove("thecircle-screenshot-selection-active"),this.selectionBox.classList.remove("thecircle-screenshot-selection-breathe")),this.sizeIndicator&&(this.sizeIndicator.style.display="none"),this.hintText&&(this.hintText.style.opacity="1")}attachEventListeners(){document.addEventListener("mousedown",this.handleMouseDown),document.addEventListener("mousemove",this.handleMouseMove),document.addEventListener("mouseup",this.handleMouseUp),document.addEventListener("keydown",this.handleKeyDown)}detachEventListeners(){document.removeEventListener("mousedown",this.handleMouseDown),document.removeEventListener("mousemove",this.handleMouseMove),document.removeEventListener("mouseup",this.handleMouseUp),document.removeEventListener("keydown",this.handleKeyDown)}handleMouseDown(e){if(!this.overlay||e.button!==0||this.toolbar&&this.toolbar.contains(e.target))return;const t=e.clientX,s=e.clientY;if(this.hasSelection&&this.currentArea){const{x:i,y:a,width:n,height:o}=this.currentArea;if(t>=i&&t<=i+n&&s>=a&&s<=a+o){this.isDragging=!0,this.dragOffsetX=t-i,this.dragOffsetY=s-a,e.preventDefault();return}else{this.triggerBreatheAnimation(),e.preventDefault();return}}this.isSelecting=!0,this.startX=t,this.startY=s,this.overlay.classList.remove("thecircle-screenshot-idle"),this.selectionBox&&(this.selectionBox.style.display="block",this.selectionBox.style.left=`${this.startX}px`,this.selectionBox.style.top=`${this.startY}px`,this.selectionBox.style.width="0px",this.selectionBox.style.height="0px"),this.sizeIndicator&&(this.sizeIndicator.style.display="block"),this.hintText&&(this.hintText.style.opacity="0"),e.preventDefault()}handleMouseMove(e){if(this.isDragging&&this.currentArea&&this.selectionBox){const r=Math.max(0,Math.min(window.innerWidth-this.currentArea.width,e.clientX-this.dragOffsetX)),l=Math.max(0,Math.min(window.innerHeight-this.currentArea.height,e.clientY-this.dragOffsetY));this.currentArea.x=r,this.currentArea.y=l,this.selectionBox.style.left=`${r}px`,this.selectionBox.style.top=`${l}px`,this.updateToolbarPosition(),this.sizeIndicator&&(this.sizeIndicator.style.left=`${r+this.currentArea.width/2}px`,this.sizeIndicator.style.top=`${l+this.currentArea.height+10}px`);return}if(!this.isSelecting||!this.selectionBox||!this.sizeIndicator)return;const t=e.clientX,s=e.clientY,i=Math.min(this.startX,t),a=Math.min(this.startY,s),n=Math.abs(t-this.startX),o=Math.abs(s-this.startY);this.selectionBox.style.left=`${i}px`,this.selectionBox.style.top=`${a}px`,this.selectionBox.style.width=`${n}px`,this.selectionBox.style.height=`${o}px`,this.sizeIndicator.textContent=`${n} × ${o}`,this.sizeIndicator.style.left=`${i+n/2}px`,this.sizeIndicator.style.top=`${a+o+10}px`}handleMouseUp(e){var r,l;if(this.isDragging){this.isDragging=!1;return}if(!this.isSelecting){this.hasSelection||(this.hideImmediately(),requestAnimationFrame(()=>{var h;(h=this.callbacks)==null||h.onSelect(null)}));return}this.isSelecting=!1;const t=e.clientX,s=e.clientY,i=Math.min(this.startX,t),a=Math.min(this.startY,s),n=Math.abs(t-this.startX),o=Math.abs(s-this.startY);if(n<10||o<10){this.hideImmediately(),requestAnimationFrame(()=>{var h;(h=this.callbacks)==null||h.onSelect(null)});return}this.currentArea={x:i,y:a,width:n,height:o},this.hasSelection=!0,(r=this.overlay)==null||r.classList.add("thecircle-screenshot-has-selection"),(l=this.selectionBox)==null||l.classList.add("thecircle-screenshot-selection-active"),this.createToolbar()}triggerBreatheAnimation(){this.selectionBox&&(this.selectionBox.classList.remove("thecircle-screenshot-selection-breathe"),this.selectionBox.offsetWidth,this.selectionBox.classList.add("thecircle-screenshot-selection-breathe"),setTimeout(()=>{var e;(e=this.selectionBox)==null||e.classList.remove("thecircle-screenshot-selection-breathe")},400))}updateToolbarPosition(){if(!this.toolbar||!this.currentArea)return;const e=this.currentArea.y+this.currentArea.height+10,t=this.currentArea.x+this.currentArea.width/2;this.toolbar.style.left=`${t}px`,e+50>window.innerHeight?this.toolbar.style.top=`${this.currentArea.y-50}px`:this.toolbar.style.top=`${e}px`}handleKeyDown(e){var t;e.key==="Escape"?(e.preventDefault(),this.hide(),(t=this.callbacks)==null||t.onCancel()):e.key==="Enter"&&this.hasSelection&&(e.preventDefault(),this.confirmSelection())}}class Ye{constructor(e){d(this,"selectedText","");d(this,"config");d(this,"screenshotSelector",null);d(this,"commandPalette",null);d(this,"currentScreenshotDataUrl","");d(this,"flowCallbacks",null);this.config=e}setCommandPalette(e){this.commandPalette=e}setSelectedText(e){this.selectedText=e}setConfig(e){this.config=e}setFlowCallbacks(e){this.flowCallbacks=e}async execute(e,t,s={}){switch(e.action){case"translate":return this.handleTranslate(t,s);case"summarize":return this.handleSummarize(t,s);case"explain":return this.handleExplain(t);case"rewrite":return this.handleRewrite(t);case"codeExplain":return this.handleCodeExplain(t);case"search":return this.handleSearch();case"copy":return this.handleCopy();case"sendToAI":return this.handleSendToAI();case"aiChat":return this.handleAIChat();case"summarizePage":return this.handleSummarizePage(t,s);case"contextChat":return this.handleContextChat();case"browseTrail":return this.handleBrowseTrail();case"screenshot":return this.handleScreenshotFlow();case"settings":return this.handleSettings();default:return{type:"error",result:"Unknown action"}}}async handleTranslate(e,t={}){return this.selectedText?this.callAIAction("translate",this.selectedText,e,t):{type:"error",result:"请先选择要翻译的文字"}}async handleSummarize(e,t={}){return this.selectedText?this.callAIAction("summarize",this.selectedText,e,t):{type:"error",result:"请先选择要总结的文字"}}async handleExplain(e){return this.selectedText?this.callAIAction("explain",this.selectedText,e):{type:"error",result:"请先选择要解释的文字"}}async handleRewrite(e){return this.selectedText?this.callAIAction("rewrite",this.selectedText,e):{type:"error",result:"请先选择要改写的文字"}}async handleCodeExplain(e){return this.selectedText?this.callAIAction("codeExplain",this.selectedText,e):{type:"error",result:"请先选择要解释的代码"}}async handleSummarizePage(e,t={}){return this.callAIAction("summarizePage",document.body.innerText.slice(0,1e4),e,t)}async handleAskPage(e,t={}){var n;const s=((n=t.pageQuestion)==null?void 0:n.trim())||"";if(!s)return{type:"error",result:"请输入你想问的问题"};const a=`Webpage content:
${document.body.innerText.slice(0,1e4)}

User question:
${s}`;return this.callAIAction("askPage",a,e,t)}async handleRewritePage(e,t={}){var p;const s=this.validateAIConfig();if(s)return{type:"error",result:s};const a=t.rewriteUseSelection!==!1?this.selectedText.trim():"",n=!!a,o=document.body.innerText.trim().slice(0,1e4),r=n?a.slice(0,1e4):o;if(!r)return{type:"error",result:"页面内容为空，无法改写"};const l=(p=t.rewriteInstruction)==null?void 0:p.trim(),h=l?`${G()}

User instruction:
${l}`:G(),g=`Title: ${document.title}
URL: ${window.location.href}

${n?"Selected content":"Content"}:
${r}`;try{const m=await O(g,h,this.config,e);return m.success?{type:"ai",result:m.result}:{type:"error",result:m.error||"AI 请求失败"}}catch(m){return{type:"error",result:`请求失败: ${m}`}}}async handleNotesPage(e,t={}){const s=document.body.innerText.slice(0,1e4);return this.callAIAction("notesPage",s,e,t)}async callAIAction(e,t,s,i={}){const a=this.validateAIConfig();if(a)return{type:"error",result:a};let n;switch(e){case"translate":n=me(i.translateTargetLanguage||this.config.preferredLanguage||"zh-CN");break;case"summarize":n=qe(this.config.summaryLanguage||"auto");break;case"explain":n=Ve();break;case"rewrite":n=G();break;case"codeExplain":n=Ue();break;case"summarizePage":n=Be(this.config.summaryLanguage||"auto");break;case"askPage":n="You are a web reading assistant. Answer the user's question using only the provided webpage content. If the answer is not present, say you cannot find it in the content. Be concise. When helpful, include short exact quotes from the content as evidence.";break;case"notesPage":n=`You are a web page note-taking assistant. Convert the provided webpage content into a concise, highly actionable Markdown note with these sections:

# Title
# Summary
# Key Points
# Action Items
# Notable Quotes
# Tags

Keep it practical and skimmable.`;break;default:return{type:"error",result:"Unknown AI action"}}try{const o=await O(t,n,this.config,s);return o.success?{type:"ai",result:o.result}:{type:"error",result:o.error||"AI 请求失败"}}catch(o){return{type:"error",result:`请求失败: ${o}`}}}validateAIConfig(){const{apiProvider:e,apiKey:t,customApiUrl:s,customModel:i}=this.config;if(e==="custom"){if(!s)return"请在设置中配置自定义 API 地址";if(!i)return"请在设置中配置自定义模型名称"}else if(!t)return`请在设置中配置 ${{openai:"OpenAI",anthropic:"Anthropic",gemini:"Google Gemini",groq:"Groq"}[e]||e} API Key`;return null}handleSearch(){const t=`https://www.google.com/search?q=${encodeURIComponent(this.selectedText||"")}`;return window.open(t,"_blank"),{type:"redirect",url:t}}handleCopy(){return this.selectedText?(navigator.clipboard.writeText(this.selectedText),{type:"success",result:"已复制到剪贴板"}):{type:"error",result:"没有选中的文字"}}handleSendToAI(){const t=`https://chat.openai.com/?q=${encodeURIComponent(this.selectedText||"")}`;return window.open(t,"_blank"),{type:"redirect",url:t}}handleAIChat(){return window.open("https://chat.openai.com/","_blank"),{type:"redirect",url:"https://chat.openai.com/"}}handleScreenshotFlow(){return this.screenshotSelector=new Fe,this.screenshotSelector.show({onSelect:async e=>{await this.captureAndShowPanel(e)},onCancel:()=>{var e;(e=this.flowCallbacks)==null||e.onToast("截图已取消")}}),{type:"silent",result:""}}async captureAndShowPanel(e){var t,s,i;try{const a=await chrome.runtime.sendMessage({type:"CAPTURE_VISIBLE_TAB"});if(!(a!=null&&a.success)||!a.dataUrl){(t=this.flowCallbacks)==null||t.onToast("截图失败");return}let n=a.dataUrl;e&&(n=await this.cropImage(a.dataUrl,e)),this.currentScreenshotDataUrl=n,this.commandPalette?this.commandPalette.showScreenshot(n,{onSave:()=>this.saveScreenshot(),onCopy:()=>this.copyScreenshotToClipboard(),onAskAI:o=>this.askAIAboutImage(o),onDescribe:()=>this.describeImage(),onGenerateImage:o=>this.generateImageFromPrompt(o),onClose:()=>{}}):(s=this.flowCallbacks)==null||s.onToast("无法显示截图面板")}catch(a){(i=this.flowCallbacks)==null||i.onToast(`截图失败: ${a}`)}}async cropImage(e,t){return new Promise((s,i)=>{const a=new Image;a.onload=()=>{const n=document.createElement("canvas"),o=n.getContext("2d");if(!o){i(new Error("Failed to get canvas context"));return}const r=window.devicePixelRatio||1;n.width=t.width*r,n.height=t.height*r,o.drawImage(a,t.x*r,t.y*r,t.width*r,t.height*r,0,0,t.width*r,t.height*r);const l=this.config.screenshot||f;s(n.toDataURL("image/png",l.imageQuality))},a.onerror=()=>i(new Error("Failed to load image")),a.src=e})}async saveScreenshot(){var e,t;try{const s=`screenshot-${Date.now()}.png`;await chrome.runtime.sendMessage({type:"DOWNLOAD_IMAGE",payload:{dataUrl:this.currentScreenshotDataUrl,filename:s}}),(e=this.flowCallbacks)==null||e.onToast("截图已保存")}catch(s){(t=this.flowCallbacks)==null||t.onToast(`保存失败: ${s}`)}}async copyScreenshotToClipboard(){var e,t;try{const i=await(await fetch(this.currentScreenshotDataUrl)).blob();await navigator.clipboard.write([new ClipboardItem({[i.type]:i})]),(e=this.flowCallbacks)==null||e.onToast("已复制到剪贴板")}catch(s){(t=this.flowCallbacks)==null||t.onToast(`复制失败: ${s}`)}}async askAIAboutImage(e){if(!this.commandPalette)return;const t=this.validateAIConfig();if(t){this.commandPalette.updateScreenshotResult(t);return}this.commandPalette.updateScreenshotResult("AI 正在分析...",!0);const s=je(e),i=await Q(this.currentScreenshotDataUrl,s,this.config,(a,n)=>{var o;(o=this.commandPalette)==null||o.updateScreenshotResult(n,!0)});i.success&&i.result?this.commandPalette.updateScreenshotResult(i.result):this.commandPalette.updateScreenshotResult(i.error||"AI 请求失败")}async describeImage(){if(!this.commandPalette)return;const e=this.validateAIConfig();if(e){this.commandPalette.updateScreenshotResult(e);return}this.commandPalette.updateScreenshotResult("AI 正在描述图片...",!0);const t=Ke(),s=await Q(this.currentScreenshotDataUrl,t,this.config,(i,a)=>{var n;(n=this.commandPalette)==null||n.updateScreenshotResult(a,!0)});s.success&&s.result?this.commandPalette.updateScreenshotResult(s.result):this.commandPalette.updateScreenshotResult(s.error||"AI 请求失败")}async generateImageFromPrompt(e){if(!this.commandPalette)return;const t=this.config.screenshot||f;if(!t.enableImageGen){this.commandPalette.updateScreenshotResult("请先在设置中启用 AI 生图功能");return}if(t.imageGenProvider==="openai"){if(!this.config.apiKey){this.commandPalette.updateScreenshotResult("使用 OpenAI 生图需要配置 API Key");return}}else if(t.imageGenProvider==="custom"&&!t.customImageGenUrl){this.commandPalette.updateScreenshotResult("请配置自定义生图 API 地址");return}this.commandPalette.updateScreenshotResult("正在生成图片...",!0);const s=await Q(this.currentScreenshotDataUrl,"用简洁的英文描述这张图片的主要内容和风格特征，不超过100词。",this.config),i=s.success?s.result:"",a=i?`Based on this context: "${i}". User request: ${e}`:e,n=await $e(a,this.config,t);n.success&&n.imageUrl?this.commandPalette.updateScreenshotGeneratedImage(n.imageUrl):this.commandPalette.updateScreenshotResult(n.error||"图像生成失败")}handleContextChat(){return{type:"contextChat",result:""}}handleBrowseTrail(){return{type:"browseTrail",result:""}}handleSettings(){return{type:"silent",result:""}}}let L=null,R=null,be=!1;function ye(){return R||xe(),R}function Xe(){return L||xe(),L}function xe(){L=document.createElement("div"),L.id="thecircle-shadow-host",L.style.cssText=`
    position: fixed;
    top: 0;
    left: 0;
    width: 0;
    height: 0;
    z-index: 2147483647;
    pointer-events: none;
  `,document.body.appendChild(L),R=L.attachShadow({mode:"open"});const c=document.createElement("div");c.id="thecircle-container",c.className="fixed top-0 left-0 w-screen h-screen pointer-events-none",R.appendChild(c)}function Qe(c){if(be||!R)return;const e=document.createElement("style");e.textContent=c,R.insertBefore(e,R.firstChild),be=!0}function we(c){const e=ye(),t=e.getElementById("thecircle-container")||e;c.style.pointerEvents="auto",t.appendChild(c)}function W(c){c.parentNode&&c.parentNode.removeChild(c)}class Ge{constructor(){d(this,"popover",null);d(this,"callbacks",null);d(this,"hideTimeout",null);d(this,"currentRange",null);d(this,"preferredPosition","above");d(this,"scrollHandler",null);d(this,"rafId",null)}show(e,t,s="above"){this.hide(),this.callbacks=t,this.preferredPosition=s;const i=window.getSelection();i&&i.rangeCount>0&&(this.currentRange=i.getRangeAt(0).cloneRange()),this.createPopover(e,s),this.setupScrollListener(),requestAnimationFrame(()=>{this.popover&&(this.popover.style.opacity="1")})}hide(){if(this.hideTimeout&&(clearTimeout(this.hideTimeout),this.hideTimeout=null),this.removeScrollListener(),this.popover){this.popover.classList.add("thecircle-selection-popover-exit");const e=this.popover;setTimeout(()=>{W(e)},150),this.popover=null}this.currentRange=null}isVisible(){return this.popover!==null}setupScrollListener(){this.scrollHandler=()=>{this.rafId===null&&(this.rafId=requestAnimationFrame(()=>{this.updatePosition(),this.rafId=null}))},window.addEventListener("scroll",this.scrollHandler,!0)}removeScrollListener(){this.scrollHandler&&(window.removeEventListener("scroll",this.scrollHandler,!0),this.scrollHandler=null),this.rafId!==null&&(cancelAnimationFrame(this.rafId),this.rafId=null)}updatePosition(){if(!this.popover||!this.currentRange)return;const e=this.currentRange.getBoundingClientRect();if(e.bottom<0||e.top>window.innerHeight){this.popover.style.opacity="0",this.popover.style.pointerEvents="none";return}else this.popover.style.opacity="1",this.popover.style.pointerEvents="auto";const{left:t,top:s}=this.calculatePosition(e,this.preferredPosition);this.popover.style.left=`${t}px`,this.popover.style.top=`${s}px`}calculatePosition(e,t){let n=e.left+e.width/2-16,o;return t==="above"?(o=e.top-32-8,o<10&&(o=e.bottom+8)):(o=e.bottom+8,o+32>window.innerHeight-10&&(o=e.top-32-8)),n<10&&(n=10),n+32>window.innerWidth-10&&(n=window.innerWidth-32-10),{left:n,top:o}}createPopover(e,t){this.popover=document.createElement("div"),this.popover.className="thecircle-selection-popover";const{left:s,top:i}=this.calculatePosition(e,t);this.popover.style.left=`${s}px`,this.popover.style.top=`${i}px`,this.popover.innerHTML=`
      <div class="thecircle-selection-popover-container">
        <button class="thecircle-selection-popover-btn" data-action="translate" title="翻译">
          ${u.translate}
        </button>
      </div>
    `,we(this.popover);const a=this.popover.querySelector('[data-action="translate"]');a==null||a.addEventListener("click",n=>{var o;n.stopPropagation(),(o=this.callbacks)==null||o.onTranslate(),this.hide()}),this.popover.addEventListener("mousedown",n=>{n.stopPropagation()})}}class ke{constructor(){d(this,"commandPalette");d(this,"menuActions");d(this,"selectionPopover");d(this,"trailRecorder");d(this,"selectionMenuItems",ee);d(this,"globalMenuItems",H);d(this,"config",C);d(this,"lastKeyTime",0);d(this,"lastKey","");d(this,"DOUBLE_TAP_DELAY",300);d(this,"activeToasts",[]);d(this,"MAX_TOASTS",4);d(this,"currentSelectedText","");this.commandPalette=new _e(C),this.menuActions=new Ye(C),this.selectionPopover=new Ge,this.trailRecorder=new Ae,this.menuActions.setFlowCallbacks({onToast:e=>this.showToast(e)}),this.menuActions.setCommandPalette(this.commandPalette),this.init()}async init(){ye();try{const e=chrome.runtime.getURL("assets/content.css"),s=await(await fetch(e)).text();Qe(s)}catch(e){console.error("The Panel: Failed to load styles",e)}await this.loadConfig(),this.setupKeyboardShortcut(),this.setupMessageListener(),this.setupStorageListener(),this.setupSelectionListener(),console.log("The Panel: Initialized with Command Palette")}async loadConfig(){try{const e=await K();this.config=e.config,this.menuActions.setConfig(e.config),this.commandPalette.setConfig(e.config),this.selectionMenuItems=e.selectionMenuItems,this.globalMenuItems=e.globalMenuItems,this.applyTheme(this.config.theme)}catch(e){console.error("The Panel: Failed to load config",e)}}setupStorageListener(){chrome.storage.onChanged.addListener(e=>{e.thecircle_config&&(this.config={...this.config,...e.thecircle_config.newValue},this.menuActions.setConfig(this.config),this.commandPalette.setConfig(this.config),this.applyTheme(this.config.theme)),e.thecircle_saved_tasks&&this.commandPalette.loadRecentSavedTasks()})}applyTheme(e){var a;const t=Xe(),s=(a=t.shadowRoot)==null?void 0:a.getElementById("thecircle-container");console.log("The Panel: Applying theme:",e);const i=["dark","light"];if(t.classList.remove(...i),s==null||s.classList.remove(...i),e==="dark")t.classList.add("dark"),s==null||s.classList.add("dark");else if(e==="light")t.classList.add("light"),s==null||s.classList.add("light");else if(e==="system"){const n=window.matchMedia("(prefers-color-scheme: dark)"),o=r=>{t.classList.remove(...i),s==null||s.classList.remove(...i),r.matches?(t.classList.add("dark"),s==null||s.classList.add("dark")):(t.classList.add("light"),s==null||s.classList.add("light"))};o(n),n.onchange=o}}setupSelectionListener(){let e=null;document.addEventListener("mouseup",t=>{var i,a,n,o;const s=t.composedPath();for(const r of s)if(r instanceof HTMLElement&&((i=r.classList)!=null&&i.contains("thecircle-selection-popover")||(a=r.classList)!=null&&a.contains("thecircle-result-panel")||(n=r.classList)!=null&&n.contains("thecircle-palette")||(o=r.classList)!=null&&o.contains("thecircle-toast")))return;e&&clearTimeout(e),e=window.setTimeout(()=>{const r=window.getSelection(),l=(r==null?void 0:r.toString().trim())||"";if(l&&r&&r.rangeCount>0){const g=r.getRangeAt(0).getBoundingClientRect();this.currentSelectedText=l;const p=this.config.popoverPosition||"above";this.selectionPopover.show(g,{onTranslate:()=>this.handleSelectionTranslate()},p)}else this.selectionPopover.hide(),this.currentSelectedText=""},10)}),document.addEventListener("mousedown",t=>{var i,a,n,o,r;const s=t.composedPath();for(const l of s)if(l instanceof HTMLElement&&((i=l.classList)!=null&&i.contains("thecircle-selection-popover")||(a=l.classList)!=null&&a.contains("thecircle-result-panel")||(n=l.classList)!=null&&n.contains("thecircle-palette")||(o=l.classList)!=null&&o.contains("thecircle-toast")))return;(r=window.getSelection())!=null&&r.toString().trim()||this.selectionPopover.hide()})}async handleSelectionTranslate(){if(!this.currentSelectedText)return;const e=this.selectionMenuItems.find(a=>a.action==="translate");if(!e){this.showToast("翻译功能未配置");return}this.selectionPopover.hide(),this.menuActions.setSelectedText(this.currentSelectedText);const t=this.currentSelectedText;let s=0;const i=async a=>{const n=++s;this.menuActions.setSelectedText(t);const o=this.config.useStreaming?(l,h)=>{n===s&&this.commandPalette.streamUpdate(l,h)}:void 0,r=await this.menuActions.execute(e,o,{translateTargetLanguage:a});n===s&&(r.type==="error"?this.commandPalette.updateAIResult(r.result||"未知错误"):r.type==="ai"&&this.commandPalette.updateAIResult(r.result||""))};this.commandPalette.setActiveCommand(e),this.commandPalette.showAIResult(e.label,{onStop:()=>V(),onTranslateLanguageChange:a=>{i(a)}},{originalText:t,resultType:"translate",translateTargetLanguage:this.config.preferredLanguage||"zh-CN",iconHtml:e.icon,actionType:"translate"}),await i(this.config.preferredLanguage||"zh-CN")}setupKeyboardShortcut(){const e=new Set;document.addEventListener("keydown",t=>{if(e.add(t.key),this.config.shortcut.startsWith("Double+")){const s=this.config.shortcut.slice(7);if(this.matchDoubleTapKey(t.key,s)){const i=Date.now();this.lastKey===t.key&&i-this.lastKeyTime<this.DOUBLE_TAP_DELAY?(t.preventDefault(),this.showMenu(),this.lastKeyTime=0,this.lastKey=""):(this.lastKeyTime=i,this.lastKey=t.key)}}else this.matchShortcut(t,this.config.shortcut)&&(t.preventDefault(),this.showMenu())}),document.addEventListener("keyup",t=>{e.delete(t.key)}),window.addEventListener("blur",()=>{e.clear()})}matchDoubleTapKey(e,t){return({Control:["Control","ControlLeft","ControlRight"],Shift:["Shift","ShiftLeft","ShiftRight"],Alt:["Alt","AltLeft","AltRight"],Meta:["Meta","MetaLeft","MetaRight"],Space:[" ","Space"],Tab:["Tab"]}[t]||[t]).includes(e)||e.toLowerCase()===t.toLowerCase()}matchShortcut(e,t){if(!e.key)return!1;const s=t.split("+"),i=s[s.length-1],a=s.includes("Ctrl"),n=s.includes("Alt"),o=s.includes("Shift");return(i==="Space"?e.key===" ":e.key.toUpperCase()===i.toUpperCase())&&(e.ctrlKey||e.metaKey)===a&&e.altKey===n&&e.shiftKey===o}setupMessageListener(){chrome.runtime.onMessage.addListener((e,t,s)=>(e.type==="TOGGLE_MENU"?(this.showMenu(),s({success:!0})):e.type==="OPEN_SETTINGS"&&(this.openSettings(),s({success:!0})),!0))}openSettings(){this.selectionPopover.hide(),this.commandPalette.isVisible()||this.commandPalette.show(this.globalMenuItems,{onSelect:async e=>{await this.handleMenuAction(e)},onClose:()=>{}}),this.commandPalette.loadSettingsMenuItems().then(()=>{this.commandPalette.showSettings()})}showMenu(){if(this.selectionPopover.hide(),this.commandPalette.isVisible()){this.commandPalette.hide();return}this.commandPalette.show(this.globalMenuItems,{onSelect:async e=>{await this.handleMenuAction(e)},onClose:()=>{}})}async handleMenuAction(e){var s;if(e.action==="settings"){await this.commandPalette.loadSettingsMenuItems(),this.commandPalette.showSettings();return}if(["translate","summarize","explain","rewrite","codeExplain","summarizePage"].includes(e.action)){const i=this.currentSelectedText||((s=window.getSelection())==null?void 0:s.toString())||"";if(e.action==="translate"){let a=0;const n=async o=>{const r=++a;this.menuActions.setSelectedText(i);const l=this.config.useStreaming?(g,p)=>{r===a&&this.commandPalette.streamUpdate(g,p)}:void 0,h=await this.menuActions.execute(e,l,{translateTargetLanguage:o});r===a&&(h.type==="error"?this.commandPalette.updateAIResult(h.result||"未知错误"):h.type==="ai"&&this.commandPalette.updateAIResult(h.result||""))};this.commandPalette.setActiveCommand(e),this.commandPalette.showAIResult(e.label,{onStop:()=>V(),onTranslateLanguageChange:o=>{n(o)}},{originalText:i,resultType:"translate",translateTargetLanguage:this.config.preferredLanguage||"zh-CN",iconHtml:e.icon,actionType:"translate"}),await n(this.config.preferredLanguage||"zh-CN")}else{this.menuActions.setSelectedText(i);const a=e.action,n=a==="summarizePage"?async()=>{this.commandPalette.setActiveCommand(e),this.commandPalette.showAIResult(e.label,{onStop:()=>V(),onRefresh:n},{originalText:i,resultType:"general",iconHtml:e.icon,actionType:a,sourceUrl:window.location.href,sourceTitle:document.title});const h=this.config.useStreaming?(p,m)=>{this.commandPalette.streamUpdate(p,m)}:void 0,g=await this.menuActions.execute(e,h);g.type==="error"?this.commandPalette.updateAIResult(g.result||"未知错误"):g.type==="ai"&&this.commandPalette.updateAIResult(g.result||"")}:void 0;if(this.commandPalette.setActiveCommand(e),this.commandPalette.showAIResult(e.label,{onStop:()=>V(),onRefresh:n},{originalText:i,resultType:"general",iconHtml:e.icon,actionType:a,sourceUrl:window.location.href,sourceTitle:document.title}))return;const r=this.config.useStreaming?(h,g)=>{this.commandPalette.streamUpdate(h,g)}:void 0,l=await this.menuActions.execute(e,r);l.type==="error"?this.commandPalette.updateAIResult(l.result||"未知错误"):l.type==="ai"&&this.commandPalette.updateAIResult(l.result||"")}}else{e.action==="screenshot"&&this.commandPalette.hide();const i=await this.menuActions.execute(e);i.type==="error"?this.showToast(i.result||"未知错误"):i.type==="success"?this.showToast(i.result||"操作成功"):i.type==="info"&&this.showToast(i.result||"")}}showToast(e){const t=document.createElement("div");if(t.className="thecircle-toast",this.activeToasts.length>=this.MAX_TOASTS){const a=this.activeToasts.shift();a&&(clearTimeout(a.timeoutId),W(a.element))}const s=this.activeToasts.length;t.style.bottom=`${24+s*50}px`,t.setAttribute("data-index",String(s)),t.textContent=e,we(t);const i=window.setTimeout(()=>{t.classList.add("thecircle-toast-exit"),setTimeout(()=>{W(t),this.activeToasts=this.activeToasts.filter(a=>a.element!==t)},200)},3e3);this.activeToasts.push({element:t,timeoutId:i})}}document.readyState==="loading"?document.addEventListener("DOMContentLoaded",()=>new ke):new ke})();
